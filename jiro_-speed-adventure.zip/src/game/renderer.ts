import { Player, Platform, Spring, Checkpoint, Coin, Enemy, Particle, SceneryItem, FinishFlag, GameState, PowerUp, GameNotification, Boss, RunStats, NPC, PlayerUpgrades } from '../types';

export const GAME_W = 960;
export const GAME_H = 540;

// Safe roundRect helper
function drawRoundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number | number[]) {
  if (typeof ctx.roundRect === 'function') {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
    return;
  }
  const rad = typeof r === 'number' ? r : r[0] || 0;
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.lineTo(x + w - rad, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
  ctx.lineTo(x + w, y + h - rad);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
  ctx.lineTo(x + rad, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rad);
  ctx.lineTo(x, y + rad);
  ctx.quadraticCurveTo(x, y, x + rad, y);
  ctx.closePath();
}

/**
 * Finds the closest ground or platform directly below the specified X coordinate and reference bottom Y.
 */
function getGroundUnder(x: number, width: number, bottomY: number, platforms: Platform[]): number | null {
  let closestY: number | null = null;
  const centerX = x + width / 2;

  for (const plat of platforms) {
    if (centerX >= plat.x - 6 && centerX <= plat.x + plat.width + 6) {
      if (plat.y >= bottomY - 6) {
        if (closestY === null || plat.y < closestY) {
          closestY = plat.y;
        }
      }
    }
  }
  return closestY;
}

export function drawBackground(
  ctx: CanvasRenderingContext2D,
  camX: number,
  clouds: SceneryItem[],
  hills: SceneryItem[],
  trees: SceneryItem[]
) {
  const time = performance.now() * 0.001;

  // 1. Sky Gradient - Rich vibrant atmosphere with warm horizon glow
  const skyGrad = ctx.createLinearGradient(0, 0, 0, GAME_H);
  skyGrad.addColorStop(0, '#1d80db');
  skyGrad.addColorStop(0.42, '#50abff');
  skyGrad.addColorStop(0.78, '#9bd5ff');
  skyGrad.addColorStop(1, '#d8efff');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, GAME_W, GAME_H);

  // 2. Sun with realistic soft multi-ring coronas and light rays
  ctx.save();
  const sunX = 140 - camX * 0.02;
  const sunY = 85;

  // Ambient sun haze
  const sunGlow = ctx.createRadialGradient(sunX, sunY, 15, sunX, sunY, 120);
  sunGlow.addColorStop(0, 'rgba(255, 250, 215, 0.95)');
  sunGlow.addColorStop(0.25, 'rgba(255, 235, 140, 0.55)');
  sunGlow.addColorStop(0.6, 'rgba(255, 220, 110, 0.18)');
  sunGlow.addColorStop(1, 'rgba(255, 210, 100, 0)');
  ctx.fillStyle = sunGlow;
  ctx.beginPath();
  ctx.arc(sunX, sunY, 120, 0, Math.PI * 2);
  ctx.fill();

  // Crisp sun core with bright rim
  const coreGrad = ctx.createRadialGradient(sunX - 4, sunY - 4, 2, sunX, sunY, 26);
  coreGrad.addColorStop(0, '#ffffff');
  coreGrad.addColorStop(0.5, '#fff7b8');
  coreGrad.addColorStop(1, '#ffde59');
  ctx.fillStyle = coreGrad;
  ctx.beginPath();
  ctx.arc(sunX, sunY, 26, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // 3. Distant Mountains - Two atmospheric layers with sun highlights
  // Far Mountains (hazy lavender-blue)
  ctx.save();
  const farMtnGrad = ctx.createLinearGradient(0, 200, 0, GAME_H);
  farMtnGrad.addColorStop(0, 'rgba(145, 175, 215, 0.7)');
  farMtnGrad.addColorStop(1, 'rgba(195, 220, 245, 0.9)');
  ctx.fillStyle = farMtnGrad;
  ctx.beginPath();
  ctx.moveTo(0, GAME_H);
  for (let x = 0; x <= GAME_W + 80; x += 60) {
    const worldX = x + camX * 0.04;
    const my = 260 + Math.sin(worldX * 0.002) * 75 + Math.cos(worldX * 0.005) * 45;
    ctx.lineTo(x, my);
  }
  ctx.lineTo(GAME_W, GAME_H);
  ctx.closePath();
  ctx.fill();

  // Near Mountains (richer slate blue with ridge highlights)
  const nearMtnGrad = ctx.createLinearGradient(0, 240, 0, GAME_H);
  nearMtnGrad.addColorStop(0, '#7599c2');
  nearMtnGrad.addColorStop(0.7, '#92b4d8');
  nearMtnGrad.addColorStop(1, '#b7d4ee');
  ctx.fillStyle = nearMtnGrad;
  ctx.beginPath();
  ctx.moveTo(0, GAME_H);
  for (let x = 0; x <= GAME_W + 80; x += 80) {
    const worldX = x + camX * 0.08;
    const my = 290 + Math.sin(worldX * 0.0035 + 1.2) * 55 + Math.cos(worldX * 0.008) * 35;
    ctx.lineTo(x, my);
  }
  ctx.lineTo(GAME_W, GAME_H);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // 4. Clouds - Puffy volumetric cartoon clouds with sunlit tops and soft shaded undersides
  ctx.save();
  clouds.forEach(c => {
    const drawX = c.x - camX * 0.18;
    if (drawX > -180 && drawX < GAME_W + 180) {
      const cw = c.width || 90;
      const ch = c.height || 36;
      const cy = c.y;

      // Cloud underside soft shadow
      ctx.fillStyle = 'rgba(185, 210, 238, 0.75)';
      ctx.beginPath();
      ctx.ellipse(drawX, cy + 5, cw * 0.48, ch * 0.42, 0, 0, Math.PI * 2);
      ctx.ellipse(drawX - cw * 0.24, cy + 8, cw * 0.32, ch * 0.4, 0, 0, Math.PI * 2);
      ctx.ellipse(drawX + cw * 0.24, cy + 8, cw * 0.32, ch * 0.4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Cloud sunlit body
      ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
      ctx.beginPath();
      ctx.ellipse(drawX, cy, cw * 0.45, ch * 0.45, 0, 0, Math.PI * 2);
      ctx.ellipse(drawX - cw * 0.24, cy + 2, cw * 0.3, ch * 0.42, 0, 0, Math.PI * 2);
      ctx.ellipse(drawX + cw * 0.24, cy + 2, cw * 0.3, ch * 0.42, 0, 0, Math.PI * 2);
      ctx.fill();

      // Top sun highlight
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.beginPath();
      ctx.ellipse(drawX - 4, cy - ch * 0.2, cw * 0.28, ch * 0.22, -0.1, 0, Math.PI * 2);
      ctx.fill();
    }
  });
  ctx.restore();

  // 5. Rolling Hills - Soft radial gradients with sunlit crest highlights and ambient shading
  ctx.save();
  hills.forEach(h => {
    const drawX = h.x - camX * 0.4;
    const hr = h.radius || 180;
    if (drawX > -hr - 50 && drawX < GAME_W + hr + 50) {
      // Radial lighting on hill: top-left (sun direction) is brighter
      const hillGrad = ctx.createRadialGradient(
        drawX - hr * 0.35,
        h.y - hr * 0.55,
        hr * 0.1,
        drawX,
        h.y,
        hr
      );
      hillGrad.addColorStop(0, '#75cb58');
      hillGrad.addColorStop(0.55, h.color || '#59b646');
      hillGrad.addColorStop(1, '#3c8e32');

      ctx.fillStyle = hillGrad;
      ctx.beginPath();
      ctx.arc(drawX, h.y, hr, Math.PI, 0, false);
      ctx.fill();

      // Sunlit rim highlight on top-left curve
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(drawX, h.y, hr - 2, Math.PI * 1.08, Math.PI * 1.55);
      ctx.stroke();
    }
  });
  ctx.restore();

  // 6. Environmental Trees - Volumetric leaf spheres, cylindrical trunks with soft cast shadows, gentle wind sway
  ctx.save();
  trees.forEach(t => {
    const drawX = t.x - camX * 0.65;
    if (drawX > -80 && drawX < GAME_W + 80) {
      const th = t.height || 75;
      const sway = Math.sin(time * 2.2 + t.x * 0.02) * 2.5;

      // Soft ground shadow under tree base
      ctx.fillStyle = 'rgba(20, 45, 25, 0.24)';
      ctx.beginPath();
      ctx.ellipse(drawX + 8, t.y + 4, 28, 8, 0, 0, Math.PI * 2);
      ctx.fill();

      // Tree Trunk - cylindrical gradient with sunlit left, shadowed right
      const trunkGrad = ctx.createLinearGradient(drawX - 6, 0, drawX + 6, 0);
      trunkGrad.addColorStop(0, '#a56934');
      trunkGrad.addColorStop(0.35, '#8c5225');
      trunkGrad.addColorStop(1, '#5d3211');
      ctx.fillStyle = trunkGrad;

      ctx.beginPath();
      ctx.moveTo(drawX - 5, t.y);
      ctx.lineTo(drawX - 4, t.y - th * 0.55);
      ctx.lineTo(drawX + 4, t.y - th * 0.55);
      ctx.lineTo(drawX + 6, t.y);
      ctx.closePath();
      ctx.fill();

      // Tree Canopy - Layered spheres with 3D sunlit highlights & deep shadow
      const crownY = t.y - th * 0.65;
      const drawCrownSphere = (cx: number, cy: number, r: number) => {
        const leafGrad = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.35, r * 0.15, cx, cy, r);
        leafGrad.addColorStop(0, '#66cb50');
        leafGrad.addColorStop(0.5, '#3b9b2c');
        leafGrad.addColorStop(0.9, '#246b19');
        leafGrad.addColorStop(1, '#174a0e');
        ctx.fillStyle = leafGrad;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fill();

        // Subtle specular leaf sheen
        ctx.fillStyle = 'rgba(255, 255, 255, 0.16)';
        ctx.beginPath();
        ctx.arc(cx - r * 0.3, cy - r * 0.3, r * 0.38, 0, Math.PI * 2);
        ctx.fill();
      };

      // Three overlapping spheres swayed gently by the breeze
      drawCrownSphere(drawX - 14 + sway * 0.8, crownY + 8, 18);
      drawCrownSphere(drawX + 14 + sway * 1.1, crownY + 8, 18);
      drawCrownSphere(drawX + sway, crownY - 6, 24);
    }
  });
  ctx.restore();
}

export function drawPlatforms(
  ctx: CanvasRenderingContext2D,
  camX: number,
  platforms: Platform[],
  springs: Spring[]
) {
  platforms.forEach(p => {
    const drawX = p.x - camX;
    if (drawX + p.width < -60 || drawX > GAME_W + 60) return;

    if (p.type === 'ground') {
      // 1. Deep Soil Body with Strata & Gradient
      const soilGrad = ctx.createLinearGradient(0, p.y + 14, 0, p.y + p.height);
      soilGrad.addColorStop(0, '#543621');
      soilGrad.addColorStop(0.18, '#6d4529');
      soilGrad.addColorStop(0.65, '#5c3920');
      soilGrad.addColorStop(1, '#3b2210');
      ctx.fillStyle = soilGrad;
      ctx.fillRect(drawX, p.y, p.width, p.height);

      // Soil strata lines and decorative embedded pebbles
      ctx.fillStyle = 'rgba(40, 22, 10, 0.35)';
      ctx.fillRect(drawX, p.y + 46, p.width, 3);
      ctx.fillRect(drawX, p.y + 88, p.width, 2.5);

      // Scattered little rounded stones with top highlight and drop shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
      for (let sx = drawX + 18; sx < drawX + p.width - 18; sx += 48) {
        // Drop shadow
        ctx.beginPath();
        ctx.ellipse(sx, p.y + 36, 5, 3, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      for (let sx = drawX + 18; sx < drawX + p.width - 18; sx += 48) {
        // Stone body
        ctx.fillStyle = '#806148';
        ctx.beginPath();
        ctx.ellipse(sx, p.y + 34, 4.5, 3, 0, 0, Math.PI * 2);
        ctx.fill();
        // Stone highlight
        ctx.fillStyle = '#aa896d';
        ctx.beginPath();
        ctx.arc(sx - 1.5, p.y + 33, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // 2. Thick Lush Grass Top Layer with Blade Tufts
      // Grass dark under-band (ambient occlusion between grass fringe and dirt)
      ctx.fillStyle = '#225d18';
      ctx.fillRect(drawX, p.y + 14, p.width, 6);

      // Main vibrant grass strip
      const grassGrad = ctx.createLinearGradient(0, p.y, 0, p.y + 18);
      grassGrad.addColorStop(0, '#62d242');
      grassGrad.addColorStop(0.4, '#48b82a');
      grassGrad.addColorStop(1, '#2c7b19');
      ctx.fillStyle = grassGrad;
      ctx.fillRect(drawX, p.y, p.width, 16);

      // Stylized grass blade fringes pointing down into the soil
      ctx.fillStyle = '#399920';
      ctx.beginPath();
      for (let gx = drawX; gx < drawX + p.width; gx += 16) {
        ctx.lineTo(gx, p.y + 16);
        ctx.lineTo(gx + 8, p.y + 25);
      }
      ctx.lineTo(drawX + p.width, p.y + 16);
      ctx.closePath();
      ctx.fill();

      // Top sunlit grass edge highlight (light from top-left)
      ctx.fillStyle = '#8af568';
      ctx.fillRect(drawX, p.y, p.width, 3);
    } else {
      // FLOATING PLATFORM
      ctx.save();

      // 1. Soft Ambient Occlusion / Shadow cast beneath the floating platform
      const dropShadowGrad = ctx.createLinearGradient(0, p.y + p.height, 0, p.y + p.height + 16);
      dropShadowGrad.addColorStop(0, 'rgba(15, 23, 42, 0.28)');
      dropShadowGrad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      ctx.fillStyle = dropShadowGrad;
      ctx.fillRect(drawX + 4, p.y + p.height, p.width - 8, 16);

      // 2. Wooden Plank Platform Body with 3D Bevel
      const woodGrad = ctx.createLinearGradient(0, p.y, 0, p.y + p.height);
      woodGrad.addColorStop(0, '#e59d58');
      woodGrad.addColorStop(0.5, '#c87d36');
      woodGrad.addColorStop(1, '#8e4b16');
      ctx.fillStyle = woodGrad;
      drawRoundRect(ctx, drawX, p.y, p.width, p.height, 7);
      ctx.fill();

      // Inner plank relief lines
      ctx.strokeStyle = 'rgba(80, 35, 8, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(drawX + p.width * 0.33, p.y + 6);
      ctx.lineTo(drawX + p.width * 0.33, p.y + p.height - 2);
      ctx.moveTo(drawX + p.width * 0.66, p.y + 6);
      ctx.lineTo(drawX + p.width * 0.66, p.y + p.height - 2);
      ctx.stroke();

      // Metallic corner rivets with highlights
      const drawRivet = (rx: number, ry: number) => {
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(rx, ry, 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#cbd5e1';
        ctx.beginPath();
        ctx.arc(rx - 0.8, ry - 0.8, 1, 0, Math.PI * 2);
        ctx.fill();
      };
      drawRivet(drawX + 6, p.y + p.height - 6);
      drawRivet(drawX + p.width - 6, p.y + p.height - 6);

      // 3. Lush Top Grass Trim
      const topGrassGrad = ctx.createLinearGradient(0, p.y, 0, p.y + 8);
      topGrassGrad.addColorStop(0, '#66da46');
      topGrassGrad.addColorStop(1, '#3a9f20');
      ctx.fillStyle = topGrassGrad;
      drawRoundRect(ctx, drawX, p.y, p.width, 8, [7, 7, 0, 0]);
      ctx.fill();

      // Sunlit lip highlight
      ctx.fillStyle = '#94f975';
      ctx.fillRect(drawX + 2, p.y, p.width - 4, 2);

      // Underside bottom edge shade
      ctx.fillStyle = 'rgba(30, 15, 5, 0.4)';
      ctx.fillRect(drawX + 2, p.y + p.height - 2.5, p.width - 4, 2.5);

      ctx.restore();
    }
  });

  // SPRINGS
  springs.forEach(s => {
    const drawX = s.x - camX;
    if (drawX < -40 || drawX > GAME_W + 40) return;

    // Soft ground shadow under spring base
    ctx.fillStyle = 'rgba(15, 23, 42, 0.35)';
    ctx.beginPath();
    ctx.ellipse(drawX + s.width / 2, s.y + s.height, s.width * 0.55, 3.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Heavy Metal Base Plate
    ctx.fillStyle = '#334155';
    drawRoundRect(ctx, drawX - 2, s.y + s.height - 5, s.width + 4, 5, 2);
    ctx.fill();

    // 3D Coiled Metallic Spring with Gradient
    ctx.strokeStyle = '#e67e22';
    ctx.lineWidth = 4.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(drawX + 6, s.y + s.height - 5);
    ctx.lineTo(drawX + s.width - 6, s.y + s.height - 9);
    ctx.lineTo(drawX + 6, s.y + s.height - 13);
    ctx.lineTo(drawX + s.width - 6, s.y + 5);
    ctx.stroke();

    // Inner highlight coil
    ctx.strokeStyle = '#f9ca24';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Top Launch Cap (bright yellow with red rubber bumper)
    const capGrad = ctx.createLinearGradient(0, s.y, 0, s.y + 7);
    capGrad.addColorStop(0, '#f9ca24');
    capGrad.addColorStop(1, '#d48806');
    ctx.fillStyle = capGrad;
    drawRoundRect(ctx, drawX + 1, s.y, s.width - 2, 7, 3);
    ctx.fill();

    // Top highlight strip
    ctx.fillStyle = '#fff4a3';
    ctx.fillRect(drawX + 4, s.y + 1, s.width - 8, 2);
  });
}

export function drawCheckpoints(ctx: CanvasRenderingContext2D, camX: number, checkpoints: Checkpoint[]) {
  const time = performance.now() * 0.003;

  checkpoints.forEach(cp => {
    const drawX = cp.x - camX;
    if (drawX < -60 || drawX > GAME_W + 60) return;

    // 1. Broad soft ground shadow anchoring the base to terrain
    ctx.fillStyle = 'rgba(15, 23, 42, 0.35)';
    ctx.beginPath();
    ctx.ellipse(drawX, cp.y + 1, 22, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. Heavy steel & stone pedestal baseplate directly on the ground line (cp.y)
    ctx.fillStyle = '#334155';
    drawRoundRect(ctx, drawX - 14, cp.y - 4, 28, 5, 2);
    ctx.fill();

    // Mid pedestal block
    ctx.fillStyle = '#475569';
    drawRoundRect(ctx, drawX - 10, cp.y - 12, 20, 9, 2);
    ctx.fill();
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(drawX - 8, cp.y - 12, 16, 2);

    // Collar ring that locks the pole into the pedestal
    ctx.fillStyle = '#64748b';
    drawRoundRect(ctx, drawX - 5, cp.y - 16, 10, 5, 1);
    ctx.fill();

    // 3. Continuous solid flagpole anchored right through collar into baseplate and ground line
    const poleGrad = ctx.createLinearGradient(drawX - 3, 0, drawX + 3, 0);
    poleGrad.addColorStop(0, '#64748b');
    poleGrad.addColorStop(0.4, '#cbd5e1');
    poleGrad.addColorStop(1, '#334155');
    ctx.fillStyle = poleGrad;
    ctx.fillRect(drawX - 2.5, cp.y - 74, 5, 72);

    // 4. Spherical finial topper
    const ballGrad = ctx.createRadialGradient(drawX - 2, cp.y - 76, 1, drawX, cp.y - 74, 7);
    ballGrad.addColorStop(0, '#ffffff');
    ballGrad.addColorStop(0.5, cp.reached ? '#00e5ff' : '#f1c40f');
    ballGrad.addColorStop(1, cp.reached ? '#0084a8' : '#b78103');
    ctx.fillStyle = ballGrad;
    ctx.beginPath();
    ctx.arc(drawX, cp.y - 74, 7, 0, Math.PI * 2);
    ctx.fill();

    // 5. Waving Pennant Flag with cloth wave ripples
    const wave = Math.sin(time * 3 + cp.id) * 3;
    ctx.save();
    if (cp.reached) {
      // Activated Checkpoint: Glowing Azure Pennant
      const flagGrad = ctx.createLinearGradient(drawX, cp.y - 68, drawX + 34, cp.y - 52);
      flagGrad.addColorStop(0, '#00e5ff');
      flagGrad.addColorStop(1, '#0077b6');
      ctx.fillStyle = flagGrad;

      ctx.beginPath();
      ctx.moveTo(drawX + 2.5, cp.y - 68);
      ctx.quadraticCurveTo(drawX + 18, cp.y - 56 + wave, drawX + 36, cp.y - 52 + wave * 1.5);
      ctx.lineTo(drawX + 2.5, cp.y - 36);
      ctx.closePath();
      ctx.fill();

      // Checkmark icon
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.5;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(drawX + 10, cp.y - 52);
      ctx.lineTo(drawX + 15, cp.y - 47);
      ctx.lineTo(drawX + 24, cp.y - 57);
      ctx.stroke();

      // Soft ambient aura pulse
      const pulse = Math.sin(time * 4) * 4;
      ctx.strokeStyle = 'rgba(0, 229, 255, 0.35)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(drawX, cp.y - 40, 26 + pulse, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      // Inactive Checkpoint: Crimson Pennant
      ctx.fillStyle = '#e74c3c';
      ctx.beginPath();
      ctx.moveTo(drawX + 2.5, cp.y - 68);
      ctx.quadraticCurveTo(drawX + 16, cp.y - 56 + wave, drawX + 32, cp.y - 52 + wave * 1.5);
      ctx.lineTo(drawX + 2.5, cp.y - 38);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  });
}

export function drawFinishFlag(ctx: CanvasRenderingContext2D, camX: number, finishFlag: FinishFlag) {
  const drawX = finishFlag.x - camX;
  if (drawX < -120 || drawX > GAME_W + 120) return;
  const time = performance.now() * 0.004;

  const groundY = finishFlag.y + finishFlag.height;

  // 1. Base drop shadow anchoring baseplate to ground
  ctx.fillStyle = 'rgba(15, 23, 42, 0.4)';
  ctx.beginPath();
  ctx.ellipse(drawX, groundY, 36, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  // 2. Heavy dual-tiered stone pedestal baseplate directly on the ground line
  ctx.fillStyle = '#334155';
  drawRoundRect(ctx, drawX - 24, groundY - 8, 48, 8, 2);
  ctx.fill();

  // Mid pedestal block
  ctx.fillStyle = '#475569';
  drawRoundRect(ctx, drawX - 16, groundY - 16, 32, 9, 2);
  ctx.fill();
  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(drawX - 14, groundY - 16, 28, 1.5);

  // Pedestal brass collar locking pole to base
  ctx.fillStyle = '#b8860b';
  drawRoundRect(ctx, drawX - 7, groundY - 21, 14, 6, 2);
  ctx.fill();

  // 3. Metallic Golden Flagpole continuous down into the collar (grounded firmly)
  const poleGrad = ctx.createLinearGradient(drawX - 4, 0, drawX + 4, 0);
  poleGrad.addColorStop(0, '#c69214');
  poleGrad.addColorStop(0.4, '#ffd700');
  poleGrad.addColorStop(1, '#8c6004');
  ctx.fillStyle = poleGrad;
  ctx.fillRect(drawX - 3.5, finishFlag.y - 8, 7, finishFlag.height - 10);

  // 4. Ornate Golden Star Topper
  const ballGrad = ctx.createRadialGradient(drawX - 2, finishFlag.y - 10, 2, drawX, finishFlag.y - 8, 12);
  ballGrad.addColorStop(0, '#ffffff');
  ballGrad.addColorStop(0.5, '#ffd700');
  ballGrad.addColorStop(1, '#b8860b');
  ctx.fillStyle = ballGrad;
  ctx.beginPath();
  ctx.arc(drawX, finishFlag.y - 8, 11, 0, Math.PI * 2);
  ctx.fill();

  // 5. Waving Victory Banner with Cloth Folds
  const flagW = 54;
  const flagH = 38;
  const wave = Math.sin(time * 3) * 4;

  ctx.save();
  const bannerGrad = ctx.createLinearGradient(drawX, finishFlag.y, drawX + flagW, finishFlag.y + flagH);
  if (finishFlag.reached) {
    bannerGrad.addColorStop(0, '#10b981');
    bannerGrad.addColorStop(0.5, '#34d399');
    bannerGrad.addColorStop(1, '#059669');
  } else {
    bannerGrad.addColorStop(0, '#0284c7');
    bannerGrad.addColorStop(0.5, '#38bdf8');
    bannerGrad.addColorStop(1, '#0369a1');
  }
  ctx.fillStyle = bannerGrad;

  ctx.beginPath();
  ctx.moveTo(drawX + 3.5, finishFlag.y - 2);
  ctx.quadraticCurveTo(drawX + flagW * 0.5, finishFlag.y + 8 + wave, drawX + flagW, finishFlag.y + 12 + wave * 1.5);
  ctx.lineTo(drawX + flagW - 6, finishFlag.y + 12 + flagH * 0.5 + wave * 1.5);
  ctx.lineTo(drawX + flagW, finishFlag.y - 2 + flagH + wave);
  ctx.quadraticCurveTo(drawX + flagW * 0.5, finishFlag.y - 2 + flagH * 0.8 + wave, drawX + 3.5, finishFlag.y - 2 + flagH);
  ctx.closePath();
  ctx.fill();

  // Golden Emblem Star on Flag
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 18px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
  ctx.shadowBlur = 4;
  ctx.fillText('★', drawX + flagW * 0.48, finishFlag.y + 16 + wave);
  ctx.restore();
}

export function drawCoins(ctx: CanvasRenderingContext2D, camX: number, coins: Coin[]) {
  const time = performance.now() * 0.005;

  coins.forEach(c => {
    if (c.collected) return;
    const drawX = c.x - camX;
    if (drawX < -30 || drawX > GAME_W + 30) return;

    const scaleX = Math.cos(time + c.animOffset);
    const floatY = c.y + Math.sin(time * 0.8 + c.animOffset) * 4;

    ctx.save();
    ctx.translate(drawX, floatY);

    // Subtle warm golden ambient glow behind coin
    const glow = ctx.createRadialGradient(0, 0, 2, 0, 0, 18);
    glow.addColorStop(0, 'rgba(255, 230, 80, 0.45)');
    glow.addColorStop(0.6, 'rgba(255, 200, 40, 0.15)');
    glow.addColorStop(1, 'rgba(255, 180, 20, 0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, 18, 0, Math.PI * 2);
    ctx.fill();

    // 3D rotating coin ellipse
    ctx.scale(Math.abs(scaleX) * 0.88 + 0.12, 1);

    // Coin Outer Rim with Metallic Gradient
    const rimGrad = ctx.createLinearGradient(-11, -11, 11, 11);
    rimGrad.addColorStop(0, '#fff385');
    rimGrad.addColorStop(0.35, '#ffd214');
    rimGrad.addColorStop(0.7, '#d49600');
    rimGrad.addColorStop(1, '#8c5900');
    ctx.fillStyle = rimGrad;
    ctx.beginPath();
    ctx.arc(0, 0, 11, 0, Math.PI * 2);
    ctx.fill();

    // Coin Inner Bevel
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = '#ffeaa7';
    ctx.stroke();

    // Inner Core
    ctx.fillStyle = '#ffc000';
    ctx.beginPath();
    ctx.arc(0, 0, 6.5, 0, Math.PI * 2);
    ctx.fill();

    // Star / Glint Center
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-1.5, -1.5, 2.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  });
}

export function drawPowerUps(
  ctx: CanvasRenderingContext2D,
  camX: number,
  powerups: PowerUp[],
  platforms?: Platform[]
) {
  const time = performance.now() * 0.004;

  powerups.forEach(p => {
    if (p.collected) return;
    const drawX = p.x - camX;
    if (drawX < -50 || drawX > GAME_W + 50) return;

    const centerX = drawX + p.width / 2;
    const floatY = p.y + Math.sin(time * 3 + p.animOffset) * 5;
    const centerY = floatY + p.height / 2;

    // Soft drop shadow under power-up
    if (platforms) {
      const groundY = getGroundUnder(p.x, p.width, p.y + p.height, platforms);
      if (groundY !== null) {
        const heightAbove = Math.max(0, groundY - (floatY + p.height));
        if (heightAbove < 220) {
          const scale = Math.max(0.2, 1 - heightAbove / 220);
          const alpha = Math.max(0.05, 0.35 * (1 - heightAbove / 220));
          ctx.save();
          ctx.fillStyle = `rgba(15, 23, 42, ${alpha})`;
          ctx.beginPath();
          ctx.ellipse(centerX, groundY, 15 * scale, 4.5 * scale, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      }
    }

    ctx.save();
    ctx.translate(centerX, centerY);

    // 1. SPEED BOOST (Electric Yellow Diamond & Lightning)
    if (p.type === 'speed') {
      const glow = ctx.createRadialGradient(0, 0, 2, 0, 0, 24);
      glow.addColorStop(0, 'rgba(253, 224, 71, 0.65)');
      glow.addColorStop(0.5, 'rgba(234, 179, 8, 0.25)');
      glow.addColorStop(1, 'rgba(202, 138, 4, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, 0, 24, 0, Math.PI * 2);
      ctx.fill();

      ctx.rotate(Math.sin(time * 2 + p.animOffset) * 0.08);
      ctx.fillStyle = '#ca8a04';
      ctx.beginPath();
      ctx.moveTo(0, -17);
      ctx.lineTo(16, 0);
      ctx.lineTo(0, 17);
      ctx.lineTo(-16, 0);
      ctx.closePath();
      ctx.fill();

      const innerGrad = ctx.createLinearGradient(-12, -12, 12, 12);
      innerGrad.addColorStop(0, '#fef08a');
      innerGrad.addColorStop(0.4, '#eab308');
      innerGrad.addColorStop(1, '#a16207');
      ctx.fillStyle = innerGrad;
      ctx.beginPath();
      ctx.moveTo(0, -14);
      ctx.lineTo(13, 0);
      ctx.lineTo(0, 14);
      ctx.lineTo(-13, 0);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(1, -9);
      ctx.lineTo(-6, 0);
      ctx.lineTo(-1, 0);
      ctx.lineTo(-3, 9);
      ctx.lineTo(6, -1);
      ctx.lineTo(1, -1);
      ctx.closePath();
      ctx.fill();

      const spAngle = time * 4 + p.animOffset;
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.arc(Math.cos(spAngle) * 18, Math.sin(spAngle) * 18, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }

    // 2. SHIELD (Azure Energy Sphere & Crest)
    else if (p.type === 'shield') {
      const pulse = Math.sin(time * 4 + p.animOffset) * 2;
      const glow = ctx.createRadialGradient(0, 0, 4, 0, 0, 25 + pulse);
      glow.addColorStop(0, 'rgba(56, 189, 248, 0.65)');
      glow.addColorStop(0.5, 'rgba(14, 165, 233, 0.25)');
      glow.addColorStop(1, 'rgba(2, 132, 199, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, 0, 25 + pulse, 0, Math.PI * 2);
      ctx.fill();

      const orbGrad = ctx.createRadialGradient(-4, -4, 2, 0, 0, 15);
      orbGrad.addColorStop(0, 'rgba(224, 242, 254, 0.95)');
      orbGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.7)');
      orbGrad.addColorStop(1, 'rgba(3, 105, 161, 0.85)');
      ctx.fillStyle = orbGrad;
      ctx.beginPath();
      ctx.arc(0, 0, 15, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.save();
      ctx.rotate(time * 2 + p.animOffset);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.ellipse(0, 0, 19, 7.5, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(19, 0, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(-5, -6);
      ctx.lineTo(5, -6);
      ctx.lineTo(5, 1);
      ctx.quadraticCurveTo(5, 6, 0, 8);
      ctx.quadraticCurveTo(-5, 6, -5, 1);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.moveTo(-3, -4);
      ctx.lineTo(3, -4);
      ctx.lineTo(3, 1);
      ctx.quadraticCurveTo(3, 4, 0, 6);
      ctx.quadraticCurveTo(-3, 4, -3, 1);
      ctx.closePath();
      ctx.fill();
    }

    // 3. EXTRA LIFE (Crimson Heart)
    else if (p.type === 'life') {
      const beat = Math.sin(time * 5 + p.animOffset) * 0.1;
      ctx.scale(1 + beat, 1 + beat);

      const glow = ctx.createRadialGradient(0, 0, 4, 0, 0, 25);
      glow.addColorStop(0, 'rgba(244, 63, 94, 0.65)');
      glow.addColorStop(0.6, 'rgba(225, 29, 72, 0.25)');
      glow.addColorStop(1, 'rgba(159, 18, 57, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, 0, 25, 0, Math.PI * 2);
      ctx.fill();

      const heartGrad = ctx.createLinearGradient(-10, -10, 10, 10);
      heartGrad.addColorStop(0, '#fda4af');
      heartGrad.addColorStop(0.3, '#f43f5e');
      heartGrad.addColorStop(1, '#9f1239');
      ctx.fillStyle = heartGrad;

      ctx.beginPath();
      ctx.moveTo(0, 4);
      ctx.bezierCurveTo(-14, -10, -14, 8, 0, 15);
      ctx.bezierCurveTo(14, 8, 14, -10, 0, 4);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.beginPath();
      ctx.ellipse(-5, 0, 3, 2, -0.4, 0, Math.PI * 2);
      ctx.fill();
    }

    // 4. COIN MAGNET (Horseshoe Magnet)
    else if (p.type === 'magnet') {
      const glow = ctx.createRadialGradient(0, 0, 4, 0, 0, 25);
      glow.addColorStop(0, 'rgba(192, 132, 252, 0.65)');
      glow.addColorStop(0.5, 'rgba(168, 85, 247, 0.25)');
      glow.addColorStop(1, 'rgba(126, 34, 206, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, 0, 25, 0, Math.PI * 2);
      ctx.fill();

      ctx.rotate(Math.sin(time * 2.5 + p.animOffset) * 0.12);

      ctx.lineWidth = 6;
      ctx.strokeStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.arc(0, -2, 11, 0, Math.PI, false);
      ctx.stroke();

      ctx.strokeStyle = '#ef4444';
      ctx.beginPath();
      ctx.moveTo(-11, -2);
      ctx.lineTo(-11, 7);
      ctx.stroke();

      ctx.strokeStyle = '#3b82f6';
      ctx.beginPath();
      ctx.moveTo(11, -2);
      ctx.lineTo(11, 7);
      ctx.stroke();

      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(-14, 7, 6, 3.5);
      ctx.fillRect(8, 7, 6, 3.5);

      const sparkOffset = Math.sin(time * 12) * 3;
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-8, 8.5);
      ctx.lineTo(0, 6 + sparkOffset);
      ctx.lineTo(8, 8.5);
      ctx.stroke();
    }

    // 5. SUPER JUMP (Blazing Flame Energy Star)
    else if (p.type === 'jump') {
      const flamePulse = Math.sin(time * 6 + p.animOffset) * 3;
      const glow = ctx.createRadialGradient(0, 0, 3, 0, 0, 25 + flamePulse);
      glow.addColorStop(0, 'rgba(251, 146, 60, 0.7)');
      glow.addColorStop(0.5, 'rgba(234, 88, 12, 0.3)');
      glow.addColorStop(1, 'rgba(154, 52, 18, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, 0, 25 + flamePulse, 0, Math.PI * 2);
      ctx.fill();

      ctx.rotate(time * 1.5 + p.animOffset);
      ctx.fillStyle = '#ea580c';
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const rot = (i * Math.PI) / 4;
        const r1 = 15;
        const r2 = 7;
        ctx.lineTo(Math.cos(rot) * r1, Math.sin(rot) * r1);
        ctx.lineTo(Math.cos(rot + Math.PI / 8) * r2, Math.sin(rot + Math.PI / 8) * r2);
      }
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const rot = (i * Math.PI) / 4;
        const r1 = 9;
        const r2 = 4;
        ctx.lineTo(Math.cos(rot) * r1, Math.sin(rot) * r1);
        ctx.lineTo(Math.cos(rot + Math.PI / 8) * r2, Math.sin(rot + Math.PI / 8) * r2);
      }
      ctx.closePath();
      ctx.fill();

      const fY = (time * 25) % 18;
      ctx.fillStyle = '#ff7700';
      ctx.beginPath();
      ctx.arc(Math.sin(fY) * 6, -10 - fY * 0.5, 2.5 * (1 - fY / 18), 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  });
}

export function drawEnemies(
  ctx: CanvasRenderingContext2D,
  camX: number,
  enemies: Enemy[],
  platforms?: Platform[]
) {
  enemies.forEach(e => {
    const drawX = e.x - camX;
    if (drawX < -60 || drawX > GAME_W + 60) return;

    const centerX = drawX + e.width / 2;
    const bottomY = e.y + e.height;

    // 1. SOFT GROUND SHADOW
    if (e.alive) {
      ctx.save();
      if (e.type === 'bumble') {
        // Flying bumble drone shadow stays on the ground underneath
        let groundY = bottomY + 25;
        if (platforms) {
          const found = getGroundUnder(e.x, e.width, bottomY, platforms);
          if (found !== null) groundY = found;
        }
        const dist = Math.max(0, groundY - bottomY);
        const shadowScale = Math.max(0.3, 1 - dist / 180);
        ctx.fillStyle = `rgba(15, 23, 42, ${0.25 * shadowScale})`;
        ctx.beginPath();
        ctx.ellipse(centerX, groundY, 14 * shadowScale, 4.5 * shadowScale, 0, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Ground patrolling enemies have direct contact soft shadow
        ctx.fillStyle = 'rgba(15, 23, 42, 0.32)';
        ctx.beginPath();
        ctx.ellipse(centerX, bottomY - 1, e.width * 0.44, 4, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // 2. ENEMY SPRITE RENDERING
    ctx.save();
    ctx.translate(centerX, e.y + e.height / 2);

    if (!e.alive) {
      // Squished state
      ctx.scale(1.4, 0.25);
      ctx.fillStyle = '#64748b';
      ctx.beginPath();
      ctx.arc(0, 0, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      return;
    }

    if (e.vx < 0) ctx.scale(-1, 1);

    if (e.type === 'sprout') {
      // SPROUT BOT - Cute round seedling bot with volumetric shading & animated feet
      const footWiggle = Math.sin(e.animFrame * 2.5) * 4;

      // Feet (rounded shoes with shading)
      ctx.fillStyle = '#c0392b';
      ctx.beginPath();
      ctx.ellipse(-7, 10 + footWiggle, 5.5, 4, 0, 0, Math.PI * 2);
      ctx.ellipse(7, 10 - footWiggle, 5.5, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Main Spherical Body with Sunlit Sphere Highlight (top-left)
      const bodyGrad = ctx.createRadialGradient(-5, -5, 2, 0, 0, 15);
      bodyGrad.addColorStop(0, '#58d68d');
      bodyGrad.addColorStop(0.65, '#27ae60');
      bodyGrad.addColorStop(1, '#196f3d');
      ctx.fillStyle = bodyGrad;
      ctx.beginPath();
      ctx.arc(0, 0, 14, 0, Math.PI * 2);
      ctx.fill();

      // Sunlit specular rim
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.beginPath();
      ctx.arc(-5, -5, 5, 0, Math.PI * 2);
      ctx.fill();

      // Sprouting Leaf Antenna on Head
      const leafSway = Math.sin(e.animFrame * 1.8) * 0.15;
      ctx.save();
      ctx.translate(0, -13);
      ctx.rotate(leafSway);
      const leafGrad = ctx.createLinearGradient(-3, -12, 3, 0);
      leafGrad.addColorStop(0, '#2ecc71');
      leafGrad.addColorStop(1, '#1e8449');
      ctx.fillStyle = leafGrad;
      ctx.beginPath();
      ctx.ellipse(0, -6, 3.5, 8, 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Cartoon Eye with Specular Glint
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(6, -2, 5, 6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(8, -2, 2.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(7.2, -3.5, 1.2, 0, Math.PI * 2);
      ctx.fill();
    } else if (e.type === 'bumble') {
      // BUMBLE DRONE - Hovering robotic bee with translucent motion-blurred wings
      const wingFlap = Math.sin(e.animFrame * 7) * 7;

      // Translucent Wings with specular rim
      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.beginPath();
      ctx.ellipse(-3, -13 + wingFlap, 11, 4.5, -0.3, 0, Math.PI * 2);
      ctx.fill();

      // 3D Bee Body
      const beeGrad = ctx.createRadialGradient(-3, -4, 2, 0, 0, 15);
      beeGrad.addColorStop(0, '#fff176');
      beeGrad.addColorStop(0.6, '#fbc02d');
      beeGrad.addColorStop(1, '#f57f17');
      ctx.fillStyle = beeGrad;
      ctx.beginPath();
      ctx.ellipse(0, 0, 14, 11, 0, 0, Math.PI * 2);
      ctx.fill();

      // Metallic Cybernetic Stripes
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-2, -10, 4, 20);
      ctx.fillRect(4, -9, 3, 18);

      // Stinger
      ctx.fillStyle = '#d32f2f';
      ctx.beginPath();
      ctx.moveTo(-14, 0);
      ctx.lineTo(-8, -4);
      ctx.lineTo(-8, 4);
      ctx.closePath();
      ctx.fill();

      // Glowing Cyan Visor Eye
      const eyeGlow = ctx.createRadialGradient(8, -2, 1, 8, -2, 5);
      eyeGlow.addColorStop(0, '#ffffff');
      eyeGlow.addColorStop(0.5, '#00e5ff');
      eyeGlow.addColorStop(1, '#0097a7');
      ctx.fillStyle = eyeGlow;
      ctx.beginPath();
      ctx.arc(8, -2, 4.8, 0, Math.PI * 2);
      ctx.fill();
    } else if (e.type === 'crawler') {
      // ROLLER CRAWLER - Armored purple beetle crawler with metallic specular plates
      const shellGrad = ctx.createRadialGradient(-4, -6, 2, 0, 0, 16);
      shellGrad.addColorStop(0, '#c084fc');
      shellGrad.addColorStop(0.6, '#9333ea');
      shellGrad.addColorStop(1, '#581c87');
      ctx.fillStyle = shellGrad;
      ctx.beginPath();
      ctx.arc(0, 0, 14, Math.PI, 0, false);
      ctx.lineTo(14, 10);
      ctx.lineTo(-14, 10);
      ctx.closePath();
      ctx.fill();

      // Segmented Plate Ribs
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 9, Math.PI, 0, false);
      ctx.stroke();

      // Animated multi-legged crawler feet
      const legWiggle = Math.sin(e.animFrame * 4) * 3;
      ctx.fillStyle = '#1e293b';
      drawRoundRect(ctx, -11 + legWiggle, 8, 7, 5, 2);
      ctx.fill();
      drawRoundRect(ctx, 4 - legWiggle, 8, 7, 5, 2);
      ctx.fill();

      // Menacing Red Visor Slot
      ctx.fillStyle = '#ef4444';
      ctx.shadowColor = '#ef4444';
      ctx.shadowBlur = 6;
      ctx.fillRect(6, -2, 6, 3.5);
      ctx.shadowBlur = 0;
    } else if (e.type === 'chonker') {
      // CHONKER - Heavy boulder rhino bot with stone horns & grumpy brow
      const stompDust = Math.sin(e.animFrame * 3) * 2;

      // Heavy Stomping Feet
      ctx.fillStyle = '#334155';
      drawRoundRect(ctx, -14, 10 + stompDust, 11, 7, 2);
      ctx.fill();
      drawRoundRect(ctx, 3, 10 - stompDust, 11, 7, 2);
      ctx.fill();

      // Boulder Body with Crags
      const rockGrad = ctx.createRadialGradient(-4, -4, 3, 0, 0, 20);
      rockGrad.addColorStop(0, '#94a3b8');
      rockGrad.addColorStop(0.65, '#475569');
      rockGrad.addColorStop(1, '#1e293b');
      ctx.fillStyle = rockGrad;
      ctx.beginPath();
      ctx.arc(0, 2, 17, 0, Math.PI * 2);
      ctx.fill();

      // Rocky Horn / Ridge on Front
      ctx.fillStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.moveTo(12, -4);
      ctx.lineTo(20, -1);
      ctx.lineTo(13, 5);
      ctx.closePath();
      ctx.fill();

      // Grumpy Furrowed Brow & Glowing Amber Eye
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(6, -3, 8, 5);
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(8, -2, 4, 3);
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(4, -5);
      ctx.lineTo(15, -2);
      ctx.stroke();
    } else if (e.type === 'hopper') {
      // HOPPER - Coiled spring frog bot that squashes and leaps
      const squash = e.jumpCooldown && e.jumpCooldown < 15 ? 0.7 : 1.0;
      ctx.scale(1 / squash, squash);

      // Coiled Metallic Spring Leg
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(0, 5);
      ctx.lineTo(-6, 8);
      ctx.lineTo(6, 11);
      ctx.lineTo(-4, 14);
      ctx.stroke();

      // Cute Round Cyan Body
      const hopGrad = ctx.createRadialGradient(-3, -4, 2, 0, -2, 14);
      hopGrad.addColorStop(0, '#67e8f9');
      hopGrad.addColorStop(0.7, '#06b6d4');
      hopGrad.addColorStop(1, '#0891b2');
      ctx.fillStyle = hopGrad;
      ctx.beginPath();
      ctx.arc(0, -3, 12, 0, Math.PI * 2);
      ctx.fill();

      // Big Curious Googly Eyes
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(5, -7, 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(6.5, -7, 2.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(6, -8, 1, 0, Math.PI * 2);
      ctx.fill();
    } else if (e.type === 'starstrider') {
      // STARSTRIDER - Celestial runner sprite with floating star crown & shimmering energy
      const hover = Math.sin(e.animFrame * 3) * 3;

      // Flowing Energy Robe/Trail
      const auraGrad = ctx.createLinearGradient(0, -15, 0, 18);
      auraGrad.addColorStop(0, '#f43f5e');
      auraGrad.addColorStop(0.5, '#ec4899');
      auraGrad.addColorStop(1, '#a855f7');
      ctx.fillStyle = auraGrad;
      ctx.beginPath();
      ctx.moveTo(0, -8 + hover);
      ctx.quadraticCurveTo(12, 4 + hover, 8, 16 + hover);
      ctx.lineTo(-8, 16 + hover);
      ctx.quadraticCurveTo(-12, 4 + hover, 0, -8 + hover);
      ctx.closePath();
      ctx.fill();

      // Floating Crystal Star Crown
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.arc(0, -18 + hover, 4, 0, Math.PI * 2);
      ctx.fill();

      // Glowing Anime Eyes
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(4, -4 + hover, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#9333ea';
      ctx.beginPath();
      ctx.arc(5, -4 + hover, 1.4, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  });
}

export function drawNPCs(
  ctx: CanvasRenderingContext2D,
  camX: number,
  npcs: NPC[],
  player: Player,
  platforms?: Platform[]
) {
  const time = performance.now() * 0.003;

  npcs.forEach(npc => {
    const drawX = npc.x - camX;
    if (drawX < -80 || drawX > GAME_W + 80) return;

    const centerX = drawX + npc.width / 2;
    const bottomY = npc.y + npc.height;
    const distToPlayer = Math.hypot(
      (player.x + player.width / 2) - (npc.x + npc.width / 2),
      (player.y + player.height / 2) - (npc.y + npc.height / 2)
    );
    const isNear = distToPlayer < 190;

    // Soft ground shadow
    ctx.save();
    let groundY = bottomY;
    if (platforms) {
      const found = getGroundUnder(npc.x, npc.width, bottomY, platforms);
      if (found !== null) groundY = found;
    }
    ctx.fillStyle = 'rgba(15, 23, 42, 0.32)';
    ctx.beginPath();
    ctx.ellipse(centerX, groundY - 1, 14, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(centerX, bottomY);

    if (npc.type === 'mira') {
      // MIRA - Friendly anime companion
      const wave = isNear ? Math.sin(time * 8) * 0.4 : 0;
      const bob = Math.sin(time * 3 + npc.animTimer) * 2;

      // Shoes
      ctx.fillStyle = '#475569';
      ctx.beginPath();
      ctx.ellipse(-5, 0, 4.5, 3, 0, 0, Math.PI * 2);
      ctx.ellipse(5, 0, 4.5, 3, 0, 0, Math.PI * 2);
      ctx.fill();

      // Body / Tunic (Lilac & Teal)
      ctx.fillStyle = '#a855f7';
      drawRoundRect(ctx, -7, -24 + bob, 14, 16, 4);
      ctx.fill();
      ctx.fillStyle = '#38bdf8';
      drawRoundRect(ctx, -5, -20 + bob, 10, 8, 2);
      ctx.fill();

      // Hair
      ctx.fillStyle = '#c084fc';
      ctx.beginPath();
      ctx.arc(0, -28 + bob, 9, 0, Math.PI * 2);
      ctx.fill();

      // Face
      ctx.fillStyle = '#fec9a1';
      ctx.beginPath();
      ctx.arc(0, -27 + bob, 7, 0, Math.PI * 2);
      ctx.fill();

      // Hair bangs & Teal Ribbon
      ctx.fillStyle = '#a855f7';
      ctx.beginPath();
      ctx.arc(0, -32 + bob, 8, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(-4, -34 + bob, 8, 3);

      // Cute Eyes
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(2, -27 + bob, 1.8, 0, Math.PI * 2);
      ctx.arc(-2, -27 + bob, 1.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(2.5, -27.5 + bob, 0.7, 0, Math.PI * 2);
      ctx.arc(-1.5, -27.5 + bob, 0.7, 0, Math.PI * 2);
      ctx.fill();

      // Cheerful Smile
      ctx.strokeStyle = '#e11d48';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(0, -24 + bob, 2.2, 0.2, Math.PI * 0.8);
      ctx.stroke();

      // Waving Arm
      ctx.save();
      ctx.translate(6, -20 + bob);
      ctx.rotate(isNear ? -0.8 + wave : -0.2);
      ctx.fillStyle = '#a855f7';
      drawRoundRect(ctx, -2, -10, 4, 10, 2);
      ctx.fill();
      ctx.fillStyle = '#fec9a1';
      ctx.beginPath();
      ctx.arc(0, -11, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

    } else if (npc.type === 'bolt') {
      // BOLT - Small hovering helper bot
      const hover = Math.sin(time * 5 + npc.animTimer) * 5;

      // Hover glow
      const glow = ctx.createRadialGradient(0, -16 + hover, 2, 0, -16 + hover, 18);
      glow.addColorStop(0, 'rgba(56, 189, 248, 0.4)');
      glow.addColorStop(1, 'rgba(56, 189, 248, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, -16 + hover, 18, 0, Math.PI * 2);
      ctx.fill();

      // Chrome/Cyan Bot Chassis
      const botGrad = ctx.createLinearGradient(-10, -26 + hover, 10, -6 + hover);
      botGrad.addColorStop(0, '#e2e8f0');
      botGrad.addColorStop(0.5, '#38bdf8');
      botGrad.addColorStop(1, '#0284c7');
      ctx.fillStyle = botGrad;
      drawRoundRect(ctx, -10, -26 + hover, 20, 18, 6);
      ctx.fill();

      // Bezel edge
      ctx.strokeStyle = '#0369a1';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Antenna with blinking beacon
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, -26 + hover);
      ctx.lineTo(0, -33 + hover);
      ctx.stroke();
      const beaconFlash = Math.sin(time * 10) > 0;
      ctx.fillStyle = beaconFlash ? '#facc15' : '#eab308';
      ctx.beginPath();
      ctx.arc(0, -34 + hover, 2.8, 0, Math.PI * 2);
      ctx.fill();

      // Visor Screen
      ctx.fillStyle = '#0f172a';
      drawRoundRect(ctx, -7, -22 + hover, 14, 9, 3);
      ctx.fill();

      // Animated Glowing Cyan Eyes (^ _ ^)
      ctx.fillStyle = '#22c55e';
      ctx.font = 'bold 8px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('^ _ ^', 0, -18 + hover);

      // Pointer Arm
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 2.5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(8, -14 + hover);
      ctx.lineTo(16, -20 + hover);
      ctx.stroke();

    } else if (npc.type === 'nova') {
      // NOVA - Mysterious star runner
      const celestialFloat = Math.sin(time * 3 + npc.animTimer) * 4;

      // Cosmic Star Aura
      const aura = ctx.createRadialGradient(0, -20 + celestialFloat, 4, 0, -20 + celestialFloat, 24);
      aura.addColorStop(0, 'rgba(192, 132, 252, 0.45)');
      aura.addColorStop(0.6, 'rgba(236, 72, 153, 0.2)');
      aura.addColorStop(1, 'rgba(147, 51, 234, 0)');
      ctx.fillStyle = aura;
      ctx.beginPath();
      ctx.arc(0, -20 + celestialFloat, 24, 0, Math.PI * 2);
      ctx.fill();

      // Flowing Celestial Robe
      const robeGrad = ctx.createLinearGradient(0, -32 + celestialFloat, 0, -2 + celestialFloat);
      robeGrad.addColorStop(0, '#4338ca');
      robeGrad.addColorStop(0.5, '#6366f1');
      robeGrad.addColorStop(1, '#a855f7');
      ctx.fillStyle = robeGrad;
      ctx.beginPath();
      ctx.moveTo(0, -30 + celestialFloat);
      ctx.lineTo(-10, -2 + celestialFloat);
      ctx.quadraticCurveTo(0, -6 + celestialFloat, 10, -2 + celestialFloat);
      ctx.closePath();
      ctx.fill();

      // Hooded Starlight Face
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.arc(0, -28 + celestialFloat, 8, 0, Math.PI * 2);
      ctx.fill();

      // Golden Star Crest Circlet
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(0, -34 + celestialFloat, 3, 0, Math.PI * 2);
      ctx.fill();

      // Twin Glowing Star Eyes
      ctx.fillStyle = '#67e8f9';
      ctx.shadowColor = '#67e8f9';
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(-3, -28 + celestialFloat, 1.8, 0, Math.PI * 2);
      ctx.arc(3, -28 + celestialFloat, 1.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    ctx.restore();

    // Floating speech bubble when Jiro is nearby
    if (isNear) {
      ctx.save();
      const bubbleY = bottomY - npc.height - 24 + Math.sin(time * 4 + npc.animTimer) * 3;
      ctx.font = 'bold 12px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      const text = npc.dialogue;
      const textWidth = ctx.measureText(text).width;
      const bubbleW = textWidth + 24;
      const bubbleH = 28;
      const bubbleX = centerX - bubbleW / 2;

      // Bubble shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      drawRoundRect(ctx, bubbleX, bubbleY + 2, bubbleW, bubbleH, 8);
      ctx.fill();

      // Bubble background
      ctx.fillStyle = 'rgba(15, 23, 42, 0.94)';
      drawRoundRect(ctx, bubbleX, bubbleY, bubbleW, bubbleH, 8);
      ctx.fill();

      // Accent rim
      const rimColor = npc.type === 'mira' ? '#ec4899' : npc.type === 'bolt' ? '#38bdf8' : '#c084fc';
      ctx.strokeStyle = rimColor;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Pointer triangle
      ctx.fillStyle = 'rgba(15, 23, 42, 0.94)';
      ctx.beginPath();
      ctx.moveTo(centerX - 6, bubbleY + bubbleH);
      ctx.lineTo(centerX + 6, bubbleY + bubbleH);
      ctx.lineTo(centerX, bubbleY + bubbleH + 6);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = rimColor;
      ctx.beginPath();
      ctx.moveTo(centerX - 6, bubbleY + bubbleH);
      ctx.lineTo(centerX, bubbleY + bubbleH + 6);
      ctx.lineTo(centerX + 6, bubbleY + bubbleH);
      ctx.stroke();

      // Dialogue text
      ctx.fillStyle = '#ffffff';
      ctx.fillText(text, centerX, bubbleY + bubbleH / 2);

      // Name Tag
      ctx.font = 'bold 9px system-ui, sans-serif';
      ctx.fillStyle = rimColor;
      ctx.fillText(npc.name.toUpperCase(), centerX, bubbleY - 6);

      ctx.restore();
    }
  });
}

/**
 * BOSS RENDERING - "Gorgonix the Mountain Behemoth"
 * Massive animated stone titan with animated stomping legs, ground dust,
 * rock plate armor, glowing amber eyes, and a pulsing crystal weak spot on its head.
 */
export function drawBoss(ctx: CanvasRenderingContext2D, camX: number, boss: Boss) {
  if (!boss.active || boss.state === 'escaped' || boss.state === 'defeated') return;

  const drawX = boss.x - camX;
  if (drawX < -150 || drawX > GAME_W + 150) return;

  const time = performance.now() * 0.004;
  const centerX = drawX + boss.width / 2;
  const bottomY = boss.y + boss.height;

  // Ground Impact Shadow
  ctx.save();
  const stompScale = Math.sin(time * 6) * 0.15;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.45)';
  ctx.beginPath();
  ctx.ellipse(centerX, bottomY, (boss.width * 0.55) * (1 + stompScale), 10 * (1 + stompScale), 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.translate(centerX, boss.y + boss.height / 2);

  // Facing direction
  if (boss.vx < 0) ctx.scale(-1, 1);

  // Hit flash if damaged recently
  if (boss.hitCooldown > 0 && Math.floor(boss.hitCooldown * 20) % 2 === 0) {
    ctx.filter = 'brightness(2.2)';
  }

  // 1. Heavy Stomping Boulder Legs
  const legCycle = Math.sin(time * 7) * 9;
  ctx.fillStyle = '#334155';
  // Back leg
  drawRoundRect(ctx, -28, 22 - legCycle, 20, 26, 6);
  ctx.fill();
  // Front leg
  ctx.fillStyle = '#475569';
  drawRoundRect(ctx, 8, 22 + legCycle, 22, 26, 6);
  ctx.fill();

  // 2. Colossal Stone Body with Chiseled Rock Plates
  const bodyGrad = ctx.createRadialGradient(-10, -10, 8, 0, 0, 48);
  bodyGrad.addColorStop(0, '#94a3b8');
  bodyGrad.addColorStop(0.5, '#475569');
  bodyGrad.addColorStop(1, '#1e293b');
  ctx.fillStyle = bodyGrad;
  ctx.beginPath();
  ctx.ellipse(0, 0, 38, 42, 0, 0, Math.PI * 2);
  ctx.fill();

  // Mossy shoulder crests
  ctx.fillStyle = '#15803d';
  ctx.beginPath();
  ctx.arc(-22, -24, 14, 0, Math.PI * 2);
  ctx.arc(18, -26, 12, 0, Math.PI * 2);
  ctx.fill();

  // 3. Rocky Curved Horns
  ctx.fillStyle = '#e2e8f0';
  // Front Horn
  ctx.beginPath();
  ctx.moveTo(22, -18);
  ctx.quadraticCurveTo(36, -34, 46, -26);
  ctx.quadraticCurveTo(32, -16, 26, -6);
  ctx.closePath();
  ctx.fill();
  // Back Horn
  ctx.fillStyle = '#94a3b8';
  ctx.beginPath();
  ctx.moveTo(-12, -26);
  ctx.quadraticCurveTo(-20, -42, -32, -36);
  ctx.quadraticCurveTo(-22, -22, -8, -16);
  ctx.closePath();
  ctx.fill();

  // 4. Glowing Amber Glowing Eyes & Craggy Mouth
  ctx.fillStyle = '#f59e0b';
  ctx.shadowColor = '#f59e0b';
  ctx.shadowBlur = 12;
  ctx.beginPath();
  ctx.ellipse(18, -10, 7, 5, 0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Pupil
  ctx.fillStyle = '#78350f';
  ctx.beginPath();
  ctx.arc(20, -10, 3, 0, Math.PI * 2);
  ctx.fill();

  // Craggy Rock Mouth with fangs
  ctx.fillStyle = '#0f172a';
  drawRoundRect(ctx, 10, 10, 24, 8, 3);
  ctx.fill();
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.moveTo(14, 10);
  ctx.lineTo(17, 14);
  ctx.lineTo(20, 10);
  ctx.moveTo(22, 10);
  ctx.lineTo(25, 14);
  ctx.lineTo(28, 10);
  ctx.fill();

  // 5. Pulsing Crystal Weak Spot on Head (The Stomp Target!)
  const crystalPulse = Math.sin(time * 8) * 3;
  const gemGrad = ctx.createRadialGradient(0, -44, 2, 0, -44, 14 + crystalPulse);
  gemGrad.addColorStop(0, '#fde047');
  gemGrad.addColorStop(0.5, '#ef4444');
  gemGrad.addColorStop(1, 'rgba(239, 68, 68, 0)');
  ctx.fillStyle = gemGrad;
  ctx.beginPath();
  ctx.arc(0, -44, 15 + crystalPulse, 0, Math.PI * 2);
  ctx.fill();

  // Crystal core diamond
  ctx.fillStyle = '#f43f5e';
  ctx.beginPath();
  ctx.moveTo(0, -54);
  ctx.lineTo(10, -44);
  ctx.lineTo(0, -34);
  ctx.lineTo(-10, -44);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(0, -50);
  ctx.lineTo(5, -44);
  ctx.lineTo(0, -40);
  ctx.lineTo(-5, -44);
  ctx.closePath();
  ctx.fill();

  ctx.restore();

  // Health Display / Name Above Boss
  ctx.save();
  ctx.textAlign = 'center';
  ctx.font = 'bold 13px system-ui, sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.shadowColor = 'rgba(0,0,0,0.8)';
  ctx.shadowBlur = 4;
  ctx.fillText(boss.name, centerX, boss.y - 34);

  // Health Crystals (3 Hearts/Crystals)
  const barW = 72;
  const startHpx = centerX - barW / 2;
  for (let i = 0; i < boss.maxHealth; i++) {
    const hx = startHpx + i * 26;
    ctx.font = '16px sans-serif';
    ctx.fillText(i < boss.health ? '💎' : '⚪', hx + 10, boss.y - 14);
  }
  ctx.restore();
}

/**
 * REDESIGNED JIRO:
 * Compact humanoid platformer hero with:
 * - Distinct slightly-oval head
 * - Small, visible athletic adventurer torso / zipped jacket with collar
 * - Two distinct arms (swinging when running, hero poses when jumping)
 * - Two distinct legs & running sneakers (animated stride cycle)
 * - Flowing adventurer headband ribbons
 * - Rich lighting: sunlit top-left highlights, ambient right-side & underside shading
 * - Soft physical ground shadow underneath Jiro on the platform below
 */
export function drawJiro(
  ctx: CanvasRenderingContext2D,
  camX: number,
  player: Player,
  platforms?: Platform[]
) {
  // Invulnerability flicker
  if (player.invulnerableTimer > 0 && Math.floor(player.invulnerableTimer / 4) % 2 === 0) {
    return;
  }

  const centerX = player.x - camX + player.width / 2;
  const bottomY = player.y + player.height;

  // 1. SOFT PHYSICAL GROUND SHADOW ON PLATFORM UNDERNEATH
  if (platforms) {
    const groundY = getGroundUnder(player.x, player.width, bottomY, platforms);
    if (groundY !== null) {
      const heightAbove = Math.max(0, groundY - bottomY);
      if (heightAbove < 260) {
        // Shadow shrinks and softens as Jiro jumps higher
        const scale = Math.max(0.25, 1 - heightAbove / 280);
        const alpha = Math.max(0.04, 0.3 * (1 - heightAbove / 260));
        // Slight shadow offset to the right due to top-left sun
        const shadowOffsetX = heightAbove * 0.08;

        ctx.save();
        ctx.fillStyle = `rgba(15, 23, 42, ${alpha})`;
        ctx.beginPath();
        ctx.ellipse(centerX + shadowOffsetX, groundY, 16 * scale, 5 * scale, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }
  }

  // 2. CHARACTER RENDERING
  ctx.save();
  ctx.translate(centerX, player.y + player.height / 2);

  if (!player.facingRight) {
    ctx.scale(-1, 1);
  }

  const speedRatio = Math.min(1, Math.abs(player.vx) / player.maxSpeed);
  player.runFrame += Math.abs(player.vx) * 0.16;

  // Subtle character tilt: lean forward while running, dynamic tilt while airborne
  if (player.isGrounded && Math.abs(player.vx) > 1) {
    ctx.rotate(0.08 + speedRatio * 0.06);
  } else if (!player.isGrounded) {
    ctx.rotate(player.vy * 0.025);
  }

  // Torso vertical bobbing
  const bobY = player.isGrounded ? Math.sin(player.runFrame * 2) * (1.8 * speedRatio) : 0;
  const time = performance.now() * 0.005;

  // ----------------------------------------------------
  // A. BACK ARM (FAR ARM) - Drawn behind torso
  // ----------------------------------------------------
  ctx.save();
  let backArmAngle = 0;
  if (!player.isGrounded) {
    // Airborne: back arm stretched back for balance/thrust
    backArmAngle = player.vy < 0 ? -0.8 : -0.3;
  } else if (Math.abs(player.vx) > 0.5) {
    // Running: swings in opposition to front leg
    backArmAngle = -Math.sin(player.runFrame) * (0.8 + speedRatio * 0.3);
  } else {
    // Idle breath
    backArmAngle = Math.sin(time) * 0.08;
  }

  ctx.translate(-2, 1 + bobY);
  ctx.rotate(backArmAngle);

  // Far arm sleeve (darker orange for depth)
  ctx.fillStyle = '#cc5200';
  drawRoundRect(ctx, -3, 0, 6, 12, 3);
  ctx.fill();

  // Far hand / glove
  ctx.fillStyle = '#cbd5e1';
  ctx.beginPath();
  ctx.arc(0, 13, 3.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // ----------------------------------------------------
  // B. BACK LEG (FAR LEG) - Drawn behind torso
  // ----------------------------------------------------
  ctx.save();
  let backLegAngle = 0;
  let backFootY = 16;
  let backFootX = -6;

  if (!player.isGrounded) {
    // Airborne jump pose: trailing leg bent back
    backLegAngle = -0.5;
    backFootX = -10;
    backFootY = 14;
  } else if (Math.abs(player.vx) > 0.5) {
    // Running stride (opposite phase)
    backLegAngle = -Math.sin(player.runFrame) * (0.75 + speedRatio * 0.35);
    backFootX = -Math.sin(player.runFrame) * (11 * speedRatio);
    backFootY = 16 - Math.abs(Math.cos(player.runFrame)) * 6;
  }

  // Far thigh / athletic pants (darker navy)
  ctx.fillStyle = '#1e293b';
  drawRoundRect(ctx, backFootX - 3, 6 + bobY, 6, 9, 2);
  ctx.fill();

  // Far Sneaker (deep crimson with white sole)
  ctx.fillStyle = '#b91c1c';
  ctx.beginPath();
  ctx.ellipse(backFootX, backFootY + bobY, 6.5, 4.5, 0, 0, Math.PI * 2);
  ctx.fill();
  // White sole
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(backFootX - 5, backFootY + bobY + 1.8, 10, 2.5);
  ctx.restore();

  // ----------------------------------------------------
  // C. TORSO / SPORTY ADVENTURER JACKET
  // ----------------------------------------------------
  ctx.save();
  ctx.translate(0, bobY);

  // Jacket main body with 3D cylindrical lighting (sunlit left, shaded right)
  const jacketGrad = ctx.createLinearGradient(-8, 0, 8, 0);
  jacketGrad.addColorStop(0, '#ff9e3b');
  jacketGrad.addColorStop(0.35, '#ff7700');
  jacketGrad.addColorStop(1, '#c44800');
  ctx.fillStyle = jacketGrad;

  // Tapered athletic vest
  ctx.beginPath();
  ctx.moveTo(-6, -4);
  ctx.lineTo(6, -4);
  ctx.lineTo(5.5, 8);
  ctx.lineTo(-5.5, 8);
  ctx.closePath();
  ctx.fill();

  // Cream/Gold Inner Undershirt & Zip Lapel
  ctx.fillStyle = '#fff3c4';
  ctx.beginPath();
  ctx.moveTo(-2, -4);
  ctx.lineTo(2, -4);
  ctx.lineTo(1, 4);
  ctx.lineTo(-1, 4);
  ctx.closePath();
  ctx.fill();

  // Golden Zipper Pull
  ctx.fillStyle = '#ffd700';
  ctx.fillRect(-1, 3, 2, 3);

  // Sporty Utility Belt
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(-6, 7.5, 12, 2.5);
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(-1.5, 7, 3, 3.5);

  ctx.restore();

  // ----------------------------------------------------
  // D. FRONT LEG (NEAR LEG) - In front of torso
  // ----------------------------------------------------
  ctx.save();
  let frontLegAngle = 0;
  let frontFootY = 16;
  let frontFootX = 6;

  if (!player.isGrounded) {
    // Airborne jump pose: front knee tucked forward in heroic leap!
    frontLegAngle = 0.6;
    frontFootX = 7;
    frontFootY = 11;
  } else if (Math.abs(player.vx) > 0.5) {
    // Running stride (front phase)
    frontLegAngle = Math.sin(player.runFrame) * (0.75 + speedRatio * 0.35);
    frontFootX = Math.sin(player.runFrame) * (11 * speedRatio);
    frontFootY = 16 - Math.abs(Math.sin(player.runFrame)) * 6;
  }

  // Front athletic shorts/pants (bright navy)
  ctx.fillStyle = '#334155';
  drawRoundRect(ctx, frontFootX - 3.5, 6 + bobY, 7, 9, 2);
  ctx.fill();

  // Front Sneaker (vibrant racing red with white sole and black grip)
  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.ellipse(frontFootX, frontFootY + bobY, 7.5, 4.8, 0, 0, Math.PI * 2);
  ctx.fill();

  // Sneaker toe highlight
  ctx.fillStyle = '#fca5a5';
  ctx.beginPath();
  ctx.arc(frontFootX + 3, frontFootY + bobY - 1, 2, 0, Math.PI * 2);
  ctx.fill();

  // White rubber sole
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(frontFootX - 6, frontFootY + bobY + 1.8, 12, 2.8);
  ctx.restore();

  // ----------------------------------------------------
  // E. HEAD & FACE - Distinct slightly-oval head
  // ----------------------------------------------------
  ctx.save();
  const headY = -12 + bobY;
  ctx.translate(0, headY);

  // 1. Dynamic Headband Ribbons (flowing backwards from behind the head)
  const ribbonWave = Math.sin(time * 8) * (3 + speedRatio * 4);
  const ribbonLen = 18 + speedRatio * 18;

  // Ribbon trail gradient
  const ribGrad = ctx.createLinearGradient(-10, 0, -10 - ribbonLen, 0);
  ribGrad.addColorStop(0, '#00d2ff');
  ribGrad.addColorStop(1, '#0077b6');
  ctx.fillStyle = ribGrad;

  // Upper ribbon
  ctx.beginPath();
  ctx.moveTo(-8, -4);
  ctx.quadraticCurveTo(-14 - speedRatio * 10, -8 + ribbonWave, -8 - ribbonLen, -6 + ribbonWave * 1.3);
  ctx.lineTo(-6 - ribbonLen, -2 + ribbonWave * 1.3);
  ctx.quadraticCurveTo(-12 - speedRatio * 8, -3 + ribbonWave, -8, 0);
  ctx.closePath();
  ctx.fill();

  // Lower ribbon
  ctx.beginPath();
  ctx.moveTo(-8, -1);
  ctx.quadraticCurveTo(-14 - speedRatio * 8, 2 - ribbonWave * 0.8, -6 - ribbonLen * 0.85, 4 - ribbonWave);
  ctx.lineTo(-4 - ribbonLen * 0.85, 7 - ribbonWave);
  ctx.quadraticCurveTo(-10 - speedRatio * 6, 4 - ribbonWave * 0.8, -8, 2);
  ctx.closePath();
  ctx.fill();

  // 2. Oval Head with Soft Sunlit Skin Shading
  const skinGrad = ctx.createRadialGradient(-3, -3, 2, 0, 0, 12);
  skinGrad.addColorStop(0, '#ffdfc4');
  skinGrad.addColorStop(0.55, '#fec9a1');
  skinGrad.addColorStop(1, '#e29a6b');
  ctx.fillStyle = skinGrad;

  ctx.beginPath();
  // Slightly oval head: width 22, height 20
  ctx.ellipse(0, 0, 11, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  // 3. Swept Adventurer Hair tufts on top/back
  ctx.fillStyle = '#804000';
  ctx.beginPath();
  ctx.moveTo(-8, -5);
  ctx.quadraticCurveTo(-12, -12, -4, -13);
  ctx.quadraticCurveTo(0, -15, 6, -11);
  ctx.quadraticCurveTo(2, -9, 0, -7);
  ctx.closePath();
  ctx.fill();

  // 4. Vibrant Cyan Headband with Gold Star Crest
  const headBandGrad = ctx.createLinearGradient(-11, 0, 11, 0);
  headBandGrad.addColorStop(0, '#0096c7');
  headBandGrad.addColorStop(0.5, '#00b4d8');
  headBandGrad.addColorStop(1, '#48cae4');
  ctx.fillStyle = headBandGrad;
  drawRoundRect(ctx, -11, -7, 22, 6.5, 3);
  ctx.fill();

  // Headband top sunlit highlight
  ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
  ctx.fillRect(-9, -7, 18, 1.5);

  // Golden Hero Crest / Badge
  ctx.fillStyle = '#ffd700';
  ctx.beginPath();
  ctx.arc(3, -4, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(2.2, -4.8, 1, 0, Math.PI * 2);
  ctx.fill();

  // 5. Expressive Anime Cartoon Eye
  // White sclera
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.ellipse(4.5, 1, 5, 6, 0.08, 0, Math.PI * 2);
  ctx.fill();

  // Glossy iris & pupil
  const eyeGrad = ctx.createLinearGradient(3, -2, 7, 5);
  eyeGrad.addColorStop(0, '#0284c7');
  eyeGrad.addColorStop(0.5, '#0369a1');
  eyeGrad.addColorStop(1, '#0f172a');
  ctx.fillStyle = eyeGrad;
  ctx.beginPath();
  ctx.ellipse(5.5, 1, 3.2, 4.5, 0.05, 0, Math.PI * 2);
  ctx.fill();

  // Dual specular glints
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(4.8, -1, 1.6, 0, Math.PI * 2);
  ctx.arc(6.8, 2.5, 1, 0, Math.PI * 2);
  ctx.fill();

  // Determined eyebrow
  ctx.strokeStyle = '#5a2500';
  ctx.lineWidth = 1.8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(1.5, -4.5);
  ctx.lineTo(8, -3.8);
  ctx.stroke();

  // 6. Confident Hero Smile
  ctx.strokeStyle = '#7c2d12';
  ctx.lineWidth = 1.8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(3.5, 5, 3.2, 0.2, Math.PI * 0.8);
  ctx.stroke();

  // Cute cheek blush
  ctx.fillStyle = 'rgba(248, 113, 113, 0.42)';
  ctx.beginPath();
  ctx.ellipse(1, 4.5, 3.5, 2, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();

  // ----------------------------------------------------
  // F. FRONT ARM (NEAR ARM) - In front of torso
  // ----------------------------------------------------
  ctx.save();
  let frontArmAngle = 0;
  if (!player.isGrounded) {
    // Airborne: front arm raised forward & up in heroic leap!
    frontArmAngle = player.vy < 0 ? 1.0 : 0.4;
  } else if (Math.abs(player.vx) > 0.5) {
    // Running: swings forward
    frontArmAngle = Math.sin(player.runFrame) * (0.8 + speedRatio * 0.3);
  } else {
    // Idle breath
    frontArmAngle = -Math.sin(time) * 0.08;
  }

  ctx.translate(1, 1 + bobY);
  ctx.rotate(frontArmAngle);

  // Near sleeve (bright orange with sunlit highlight)
  const armGrad = ctx.createLinearGradient(-3, 0, 3, 0);
  armGrad.addColorStop(0, '#ff9e3b');
  armGrad.addColorStop(1, '#ff6a00');
  ctx.fillStyle = armGrad;
  drawRoundRect(ctx, -3, 0, 6, 12, 3);
  ctx.fill();

  // White cuff
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(-3, 10, 6, 2);

  // Near hand / clenched glove
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0, 13.5, 3.8, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(15, 23, 42, 0.15)';
  ctx.beginPath();
  ctx.arc(0.5, 14.5, 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();

  ctx.restore();

  // Active Power-Up Visual Auras on Jiro
  const charCenterY = player.y + player.height / 2;

  // 1. Shield Energy Forcefield Bubble
  if (player.shield) {
    const sTime = performance.now() * 0.004;
    const pulse = Math.sin(sTime * 4) * 2;
    const sRadius = 26 + pulse;

    ctx.save();
    ctx.translate(centerX, charCenterY);

    const glow = ctx.createRadialGradient(0, 0, 10, 0, 0, sRadius + 8);
    glow.addColorStop(0, 'rgba(56, 189, 248, 0.15)');
    glow.addColorStop(0.7, 'rgba(14, 165, 233, 0.35)');
    glow.addColorStop(1, 'rgba(2, 132, 199, 0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, sRadius + 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'rgba(56, 189, 248, 0.18)';
    ctx.beginPath();
    ctx.arc(0, 0, sRadius, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.8;
    ctx.stroke();

    ctx.save();
    ctx.rotate(sTime * 2);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.ellipse(0, 0, sRadius + 4, (sRadius + 4) * 0.36, 0, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(sRadius + 4, 0, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.restore();
  }

  // 2. Coin Magnet Flux Aura
  if (player.coinMagnetTimer > 0) {
    const mTime = performance.now() * 0.005;
    ctx.save();
    ctx.translate(centerX, charCenterY);
    const mPulse = Math.sin(mTime * 5) * 3;
    ctx.strokeStyle = 'rgba(192, 132, 252, 0.45)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.arc(0, 0, 30 + mPulse, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }
}

export function renderParticles(ctx: CanvasRenderingContext2D, camX: number, particles: Particle[]) {
  particles.forEach(p => {
    ctx.save();
    ctx.globalAlpha = Math.max(0, p.alpha);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x - camX, p.y, p.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  });
}

export function drawHUD(
  ctx: CanvasRenderingContext2D,
  player: Player,
  notifications?: GameNotification[],
  boss?: Boss
) {
  ctx.save();
  const padding = 16;
  const topY = 16;

  const drawPill = (x: number, y: number, w: number, h: number, icon: string, label: string, val: string) => {
    // Soft shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
    drawRoundRect(ctx, x, y + 2, w, h, h / 2);
    ctx.fill();

    // Dark glass pill
    ctx.fillStyle = 'rgba(15, 23, 42, 0.84)';
    drawRoundRect(ctx, x, y, w, h, h / 2);
    ctx.fill();

    // Top highlight rim
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.font = '16px sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(icon, x + 8, y + h / 2);

    ctx.font = 'bold 9.5px system-ui, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText(label, x + 30, y + h / 2 - 5);

    ctx.font = 'bold 13.5px system-ui, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(val, x + 30, y + h / 2 + 7);
  };

  // 1. SCORE
  drawPill(padding, topY, 115, 38, '🏆', 'SCORE', player.score.toLocaleString());

  // 2. DISTANCE
  drawPill(padding + 122, topY, 115, 38, '🏃', 'DISTANCE', `${Math.floor(player.distance)}m`);

  // 3. COINS
  drawPill(padding + 244, topY, 95, 38, '🪙', 'COINS', `${player.coins}`);

  // 4. LIVES (5 hearts)
  ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
  drawRoundRect(ctx, padding + 346, topY + 2, 130, 38, 19);
  ctx.fill();
  ctx.fillStyle = 'rgba(15, 23, 42, 0.84)';
  drawRoundRect(ctx, padding + 346, topY, 130, 38, 19);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
  ctx.stroke();

  ctx.font = '14px sans-serif';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  let hearts = '';
  for (let i = 0; i < 5; i++) {
    hearts += i < player.lives ? '❤️' : '🖤';
  }
  ctx.fillText(hearts, padding + 355, topY + 19);

  // 5. TIME
  const mins = Math.floor(player.timeElapsed / 60);
  const secs = Math.floor(player.timeElapsed % 60);
  const ms = Math.floor((player.timeElapsed % 1) * 10);
  const timeStr = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms}`;
  drawPill(GAME_W - padding - 115, topY, 115, 38, '⏱️', 'TIME', timeStr);

  // --- BOSS ENCOUNTER NOTIFIER & ESCAPE HUD ---
  if (boss && boss.active) {
    const time = performance.now() * 0.005;

    if (boss.state === 'warning') {
      // Boss Approaching Banner
      const flash = Math.sin(time * 8) > 0;
      const bW = 380;
      const bH = 40;
      const bX = GAME_W / 2 - bW / 2;
      const bY = 62;

      ctx.fillStyle = flash ? 'rgba(239, 68, 68, 0.92)' : 'rgba(15, 23, 42, 0.92)';
      drawRoundRect(ctx, bX, bY, bW, bH, 10);
      ctx.fill();
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.font = 'bold 15px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = flash ? '#ffffff' : '#fde047';
      ctx.fillText('⚠️ WARNING: BOSS APPROACHING! ⚠️', GAME_W / 2, bY + bH / 2);
    } else if (boss.state === 'chasing') {
      // Boss Chasing Escape Bar
      const bW = 420;
      const bH = 48;
      const bX = GAME_W / 2 - bW / 2;
      const bY = 62;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.94)';
      drawRoundRect(ctx, bX, bY, bW, bH, 12);
      ctx.fill();
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Boss name & HP
      ctx.font = 'bold 12px system-ui, sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#f87171';
      ctx.fillText(`BOSS: ${boss.name}`, bX + 14, bY + 16);

      // HP crystals
      let hpStr = '';
      for (let i = 0; i < boss.maxHealth; i++) {
        hpStr += i < boss.health ? '💎' : '⚪';
      }
      ctx.font = '14px sans-serif';
      ctx.fillText(hpStr, bX + 160, bY + 16);

      // Escape progress
      const escapeRatio = Math.min(1, Math.max(0, boss.chaseDistance / boss.escapeGoal));
      ctx.font = 'bold 11px system-ui, sans-serif';
      ctx.textAlign = 'right';
      ctx.fillStyle = '#38bdf8';
      ctx.fillText(`ESCAPE: ${Math.floor(boss.chaseDistance)}m / ${boss.escapeGoal}m`, bX + bW - 14, bY + 16);

      // Progress bar track
      const barW = bW - 28;
      const barH = 8;
      const barX = bX + 14;
      const barY = bY + 30;

      ctx.fillStyle = '#1e293b';
      drawRoundRect(ctx, barX, barY, barW, barH, 4);
      ctx.fill();

      // Progress bar fill
      if (escapeRatio > 0) {
        const barGrad = ctx.createLinearGradient(barX, 0, barX + barW * escapeRatio, 0);
        barGrad.addColorStop(0, '#22c55e');
        barGrad.addColorStop(1, '#38bdf8');
        ctx.fillStyle = barGrad;
        drawRoundRect(ctx, barX, barY, Math.max(8, barW * escapeRatio), barH, 4);
        ctx.fill();
      }
    }
  }

  // --- POWER STATUS INDICATORS ---
  const activePowers: Array<{ name: string; icon: string; color: string; bg: string; border: string; ratio: number; timeText: string }> = [];
  if (player.speedBoostTimer > 0) {
    activePowers.push({
      name: 'SPEED BOOST',
      icon: '⚡',
      color: '#facc15',
      bg: 'rgba(234, 179, 8, 0.25)',
      border: '#eab308',
      ratio: Math.min(1, player.speedBoostTimer / 7.0),
      timeText: `${player.speedBoostTimer.toFixed(1)}s`
    });
  }
  if (player.shield) {
    activePowers.push({
      name: 'SHIELD',
      icon: '🛡️',
      color: '#38bdf8',
      bg: 'rgba(14, 165, 233, 0.25)',
      border: '#0ea5e9',
      ratio: 1.0,
      timeText: '1-HIT'
    });
  }
  if (player.coinMagnetTimer > 0) {
    activePowers.push({
      name: 'MAGNET',
      icon: '🧲',
      color: '#c084fc',
      bg: 'rgba(168, 85, 247, 0.25)',
      border: '#a855f7',
      ratio: Math.min(1, player.coinMagnetTimer / 8.0),
      timeText: `${player.coinMagnetTimer.toFixed(1)}s`
    });
  }
  if (player.superJumpTimer > 0) {
    activePowers.push({
      name: 'SUPER JUMP',
      icon: '🔥',
      color: '#fb923c',
      bg: 'rgba(249, 115, 22, 0.25)',
      border: '#f97316',
      ratio: Math.min(1, player.superJumpTimer / 7.0),
      timeText: `${player.superJumpTimer.toFixed(1)}s`
    });
  }

  if (activePowers.length > 0) {
    const startY = (boss && boss.active) ? 118 : 62;
    let curX = padding;
    activePowers.forEach(pow => {
      const pillW = 142;
      const pillH = 28;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
      drawRoundRect(ctx, curX, startY, pillW, pillH, 8);
      ctx.fill();
      ctx.strokeStyle = pow.border;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      if (pow.ratio > 0 && pow.ratio < 1) {
        ctx.fillStyle = pow.bg;
        drawRoundRect(ctx, curX + 2, startY + 2, (pillW - 4) * pow.ratio, pillH - 4, 6);
        ctx.fill();
      }

      ctx.font = '13px sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(pow.icon, curX + 7, startY + pillH / 2);

      ctx.font = 'bold 10px system-ui, sans-serif';
      ctx.fillStyle = pow.color;
      ctx.fillText(pow.name, curX + 26, startY + pillH / 2 - 4);

      ctx.font = 'bold 11px monospace';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'right';
      ctx.fillText(pow.timeText, curX + pillW - 7, startY + pillH / 2);

      curX += pillW + 8;
    });
  }

  // --- FLOATING NOTIFICATION BANNERS ---
  if (notifications && notifications.length > 0) {
    notifications.forEach(notif => {
      const alpha = Math.min(1, notif.timer / 0.3);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.textAlign = 'center';

      const badgeW = 280;
      const badgeH = notif.subtext ? 50 : 38;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
      drawRoundRect(ctx, GAME_W / 2 - badgeW / 2, notif.y - badgeH / 2, badgeW, badgeH, 12);
      ctx.fill();
      ctx.strokeStyle = notif.color;
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.shadowColor = notif.color;
      ctx.shadowBlur = 10;
      ctx.font = 'bold 16px system-ui, sans-serif';
      ctx.fillStyle = notif.color;
      ctx.fillText(notif.text, GAME_W / 2, notif.subtext ? notif.y - 6 : notif.y + 1);

      if (notif.subtext) {
        ctx.shadowBlur = 0;
        ctx.font = '12px system-ui, sans-serif';
        ctx.fillStyle = '#cbd5e1';
        ctx.fillText(notif.subtext, GAME_W / 2, notif.y + 14);
      }

      ctx.restore();
    });
  }

  ctx.restore();
}

function drawButton(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  text: string,
  bgColor: string
) {
  ctx.save();
  // Soft button shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
  drawRoundRect(ctx, x, y + 4, w, h, 10);
  ctx.fill();

  // Button face
  ctx.fillStyle = bgColor;
  drawRoundRect(ctx, x, y, w, h, 10);
  ctx.fill();

  // Bevel top highlight
  ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
  drawRoundRect(ctx, x, y, w, h / 2, [10, 10, 0, 0]);
  ctx.fill();

  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#ffffff';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
  ctx.shadowBlur = 4;
  ctx.fillText(text, x + w / 2, y + h / 2);
  ctx.restore();
}

export function drawStartScreen(ctx: CanvasRenderingContext2D, runStats?: RunStats, coinBalance: number = 0) {
  ctx.fillStyle = 'rgba(10, 16, 30, 0.84)';
  ctx.fillRect(0, 0, GAME_W, GAME_H);

  ctx.save();
  ctx.textAlign = 'center';

  const titleBob = Math.sin(performance.now() * 0.003) * 5;
  ctx.font = '900 46px system-ui, -apple-system, sans-serif';

  ctx.fillStyle = '#0f172a';
  ctx.fillText('JIRO: SPEED ADVENTURE', GAME_W / 2, 112 + titleBob);

  ctx.fillStyle = '#ff9f1c';
  ctx.fillText('JIRO: SPEED ADVENTURE', GAME_W / 2, 108 + titleBob);

  ctx.font = '600 14px system-ui, sans-serif';
  ctx.fillStyle = '#38bdf8';
  ctx.fillText('FAST-PACED ENDLESS PLATFORMER • PROCEDURAL EXPANSION', GAME_W / 2, 142);

  // Mascot Jiro Preview on Title Screen
  const mx = GAME_W / 2;
  const my = 205 + titleBob * 0.5;
  ctx.save();
  ctx.translate(mx, my);
  ctx.scale(1.6, 1.6);

  // Torso
  ctx.fillStyle = '#ff7b00';
  drawRoundRect(ctx, -5, -2, 10, 11, 2);
  ctx.fill();
  ctx.fillStyle = '#fff3c4';
  ctx.fillRect(-1.5, -2, 3, 6);

  // Legs & Shoes
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(-5, 9, 4, 6);
  ctx.fillRect(1, 9, 4, 6);
  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.ellipse(-3, 16, 5, 3.5, 0, 0, Math.PI * 2);
  ctx.ellipse(3, 16, 5, 3.5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Arms
  ctx.fillStyle = '#ff7b00';
  drawRoundRect(ctx, -9, 0, 4, 9, 2);
  ctx.fill();
  drawRoundRect(ctx, 5, 0, 4, 9, 2);
  ctx.fill();

  // Head
  ctx.fillStyle = '#fec9a1';
  ctx.beginPath();
  ctx.ellipse(0, -9, 9.5, 9, 0, 0, Math.PI * 2);
  ctx.fill();

  // Headband
  ctx.fillStyle = '#00b4d8';
  drawRoundRect(ctx, -10, -13, 20, 5, 2.5);
  ctx.fill();
  ctx.fillStyle = '#ffd700';
  ctx.beginPath();
  ctx.arc(3, -10.5, 2.2, 0, Math.PI * 2);
  ctx.fill();

  // Eye
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.ellipse(4, -8, 4, 5, 0.05, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.arc(5, -8, 2.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(4.2, -9.5, 1, 0, Math.PI * 2);
  ctx.fill();

  // Smile
  ctx.strokeStyle = '#7c2d12';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(3, -4, 2.5, 0.2, Math.PI * 0.8);
  ctx.stroke();

  ctx.restore();

  // Best Records & Coin Balance Pill
  const sW = 540;
  const sH = 34;
  const sX = GAME_W / 2 - sW / 2;
  const sY = 254;

  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
  drawRoundRect(ctx, sX, sY, sW, sH, 10);
  ctx.fill();
  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  const bestDist = runStats ? runStats.bestDistance : 0;
  const bestScore = runStats ? runStats.bestScore : 0;
  ctx.font = 'bold 12px system-ui, sans-serif';
  ctx.fillStyle = '#fde047';
  ctx.fillText(
    `★ BEST: ${bestDist.toLocaleString()}m   •   HIGH SCORE: ${bestScore.toLocaleString()}   •   🪙 BANK: ${coinBalance.toLocaleString()}`,
    GAME_W / 2,
    sY + sH / 2 + 1
  );

  // 4 Navigation Buttons
  drawButton(ctx, GAME_W / 2 - 130, 304, 260, 46, '▶ START RUN', '#22c55e');
  drawButton(ctx, GAME_W / 2 - 130, 356, 260, 42, '🛒 UPGRADE SHOP', '#f59e0b');
  drawButton(ctx, GAME_W / 2 - 130, 404, 260, 42, '📖 HOW TO PLAY', '#3b82f6');
  drawButton(ctx, GAME_W / 2 - 130, 452, 260, 40, '⚙️ SETTINGS', '#6366f1');

  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText('Press [Space] to quick-start • Arrow Keys or Touch/Swipe to run and jump', GAME_W / 2, 516);
  ctx.restore();
}

export function drawShopScreen(
  ctx: CanvasRenderingContext2D,
  coinBalance: number,
  upgrades: PlayerUpgrades,
  message?: string
) {
  ctx.fillStyle = 'rgba(10, 16, 30, 0.94)';
  ctx.fillRect(0, 0, GAME_W, GAME_H);

  ctx.save();
  ctx.textAlign = 'center';

  // Header
  ctx.font = '900 36px system-ui, sans-serif';
  ctx.fillStyle = '#facc15';
  ctx.fillText('UPGRADE SHOP', GAME_W / 2, 54);

  ctx.font = '500 13px system-ui, sans-serif';
  ctx.fillStyle = '#cbd5e1';
  ctx.fillText('Spend run coins to permanently boost Jiro\'s capabilities', GAME_W / 2, 76);

  // Coin Balance Banner
  const bW = 240;
  const bH = 34;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
  drawRoundRect(ctx, GAME_W / 2 - bW / 2, 88, bW, bH, 10);
  ctx.fill();
  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.font = 'bold 15px system-ui, sans-serif';
  ctx.fillStyle = '#fde047';
  ctx.fillText(`🪙 COINS: ${coinBalance.toLocaleString()}`, GAME_W / 2, 105);

  const costs: Record<keyof PlayerUpgrades, number[]> = {
    speed: [100, 250, 500, 800],
    jump: [100, 250, 500, 800],
    magnet: [150, 300, 600, 900],
    shield: [200, 400, 750, 1000]
  };

  const items: Array<{
    key: keyof PlayerUpgrades;
    icon: string;
    title: string;
    desc: string;
    color: string;
  }> = [
    {
      key: 'speed',
      icon: '⚡',
      title: 'SPEED ACCELERATOR',
      desc: '+5% Max run velocity per tier. Smoother sprint response.',
      color: '#facc15'
    },
    {
      key: 'jump',
      icon: '🔥',
      title: 'SUPER SPRING JUMP',
      desc: '+3.5% Jump force per tier. Reach higher floating platforms.',
      color: '#fb923c'
    },
    {
      key: 'magnet',
      icon: '🧲',
      title: 'COIN MAGNET RADIUS',
      desc: '+35px pull distance & +1.0s power-up duration per tier.',
      color: '#c084fc'
    },
    {
      key: 'shield',
      icon: '🛡️',
      title: 'SHIELD GENERATOR',
      desc: 'Tier 1+ spawns a free Shield each run & extends break immunity.',
      color: '#38bdf8'
    }
  ];

  items.forEach((it, idx) => {
    const cardY = 136 + idx * 76;
    const cardW = 760;
    const cardH = 68;
    const cardX = GAME_W / 2 - cardW / 2;

    const level = upgrades[it.key];
    const isMax = level >= 4;
    const cost = isMax ? 0 : costs[it.key][level];
    const canAfford = !isMax && coinBalance >= cost;

    // Card background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
    drawRoundRect(ctx, cardX, cardY, cardW, cardH, 12);
    ctx.fill();
    ctx.strokeStyle = it.color;
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Icon box
    ctx.fillStyle = 'rgba(30, 41, 59, 0.9)';
    drawRoundRect(ctx, cardX + 12, cardY + 10, 48, 48, 10);
    ctx.fill();
    ctx.font = '24px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(it.icon, cardX + 36, cardY + 34);

    // Title and Description
    ctx.textAlign = 'left';
    ctx.font = 'bold 15px system-ui, sans-serif';
    ctx.fillStyle = it.color;
    ctx.fillText(it.title, cardX + 70, cardY + 24);

    ctx.font = '12px system-ui, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText(it.desc, cardX + 70, cardY + 46);

    // Level Pips
    const pipsX = cardX + 460;
    ctx.font = 'bold 11px system-ui, sans-serif';
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText(`LVL ${level}/4`, pipsX, cardY + 24);

    for (let p = 0; p < 4; p++) {
      ctx.fillStyle = p < level ? it.color : '#334155';
      drawRoundRect(ctx, pipsX + p * 20, cardY + 34, 16, 12, 3);
      ctx.fill();
    }

    // Upgrade Button
    const btnW = 140;
    const btnH = 42;
    const btnX = cardX + cardW - btnW - 14;
    const btnY = cardY + 13;

    if (isMax) {
      ctx.fillStyle = '#334155';
      drawRoundRect(ctx, btnX, btnY, btnW, btnH, 8);
      ctx.fill();
      ctx.font = 'bold 13px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('★ MAXED', btnX + btnW / 2, btnY + btnH / 2);
    } else {
      const btnColor = canAfford ? '#22c55e' : '#475569';
      drawButton(ctx, btnX, btnY, btnW, btnH, `🪙 ${cost}`, btnColor);
    }
  });

  if (message) {
    ctx.font = 'bold 13px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#38bdf8';
    ctx.fillText(message, GAME_W / 2, 452);
  }

  // Back Button
  drawButton(ctx, GAME_W / 2 - 110, 474, 220, 44, '← MAIN MENU', '#64748b');
  ctx.restore();
}

export function drawHowToPlayScreen(ctx: CanvasRenderingContext2D) {
  ctx.fillStyle = 'rgba(10, 16, 30, 0.92)';
  ctx.fillRect(0, 0, GAME_W, GAME_H);

  ctx.save();
  ctx.textAlign = 'center';

  ctx.font = '900 34px system-ui, sans-serif';
  ctx.fillStyle = '#38bdf8';
  ctx.fillText('HOW TO PLAY & POWER-UPS', GAME_W / 2, 50);

  // Left Column: Controls
  const cW = 410;
  const leftX = 54;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
  drawRoundRect(ctx, leftX, 74, cW, 375, 12);
  ctx.fill();
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.fillStyle = '#38bdf8';
  ctx.fillText('GAME CONTROLS', leftX + cW / 2, 102);

  const controls = [
    { key: 'A / D  or  ◀ / ▶', desc: 'Move Left / Right' },
    { key: 'SPACE / W / ▲', desc: 'Jump (Hold for higher air)' },
    { key: 'TOUCH BUTTONS', desc: 'On-Screen ◀ ▶ and ▲ Jump' },
    { key: 'SWIPE GESTURES', desc: 'Swipe Left/Right run, Up jump' },
    { key: 'P KEY', desc: 'Pause / Resume Run' },
    { key: 'R KEY', desc: 'Quick Restart on Game Over' }
  ];

  controls.forEach((c, idx) => {
    const rowY = 126 + idx * 48;
    ctx.fillStyle = '#1e293b';
    drawRoundRect(ctx, leftX + 16, rowY, 150, 36, 8);
    ctx.fill();
    ctx.strokeStyle = '#475569';
    ctx.stroke();

    ctx.font = 'bold 12px monospace';
    ctx.fillStyle = '#f8fafc';
    ctx.textAlign = 'center';
    ctx.fillText(c.key, leftX + 91, rowY + 22);

    ctx.font = '500 13px system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText(c.desc, leftX + 178, rowY + 22);
  });

  // Right Column: Power-Up Guide
  const rightX = GAME_W - 54 - cW;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
  drawRoundRect(ctx, rightX, 74, cW, 375, 12);
  ctx.fill();
  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#facc15';
  ctx.fillText('POWER-UP GUIDE', rightX + cW / 2, 102);

  const powerups = [
    { icon: '⚡', name: 'SPEED BOOST (7s)', desc: '+60% sprint velocity & acceleration rush.', color: '#facc15' },
    { icon: '🛡️', name: 'SHIELD (1-Hit)', desc: 'Blocks 1 enemy hit with zero lives lost.', color: '#38bdf8' },
    { icon: '❤️', name: 'EXTRA LIFE', desc: '+1 Life (max 5) or +500 Score if already full.', color: '#ef4444' },
    { icon: '🧲', name: 'COIN MAGNET (8s)', desc: 'Pulls every nearby coin straight to Jiro.', color: '#c084fc' },
    { icon: '🔥', name: 'SUPER JUMP (7s)', desc: 'Launches Jiro high to reach sky coin routes.', color: '#fb923c' }
  ];

  powerups.forEach((p, idx) => {
    const rowY = 124 + idx * 60;
    ctx.fillStyle = '#1e293b';
    drawRoundRect(ctx, rightX + 14, rowY, 44, 44, 10);
    ctx.fill();
    ctx.font = '22px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(p.icon, rightX + 36, rowY + 29);

    ctx.textAlign = 'left';
    ctx.font = 'bold 13px system-ui, sans-serif';
    ctx.fillStyle = p.color;
    ctx.fillText(p.name, rightX + 68, rowY + 18);

    ctx.font = '12px system-ui, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText(p.desc, rightX + 68, rowY + 36);
  });

  // Back Button
  drawButton(ctx, GAME_W / 2 - 110, 468, 220, 44, '← MAIN MENU', '#64748b');
  ctx.restore();
}

export function drawSettingsScreen(
  ctx: CanvasRenderingContext2D,
  soundEnabled: boolean,
  runStats?: RunStats,
  resetConfirm: boolean = false
) {
  ctx.fillStyle = 'rgba(10, 16, 30, 0.92)';
  ctx.fillRect(0, 0, GAME_W, GAME_H);

  ctx.save();
  ctx.textAlign = 'center';

  ctx.font = '900 36px system-ui, sans-serif';
  ctx.fillStyle = '#6366f1';
  ctx.fillText('SETTINGS', GAME_W / 2, 65);

  ctx.font = '500 14px system-ui, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText('Configure audio, screen display, and game data', GAME_W / 2, 95);

  // Settings Cards
  const cW = 520;
  const startY = 130;

  // 1. Audio
  ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
  drawRoundRect(ctx, GAME_W / 2 - cW / 2, startY, cW, 76, 12);
  ctx.fill();
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('Sound Effects & Audio', GAME_W / 2 - cW / 2 + 24, startY + 32);
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText('Toggle synthesized sound and fanfare', GAME_W / 2 - cW / 2 + 24, startY + 52);

  drawButton(
    ctx,
    GAME_W / 2 + cW / 2 - 170,
    startY + 16,
    146,
    44,
    soundEnabled ? '🔊 ON' : '🔇 MUTED',
    soundEnabled ? '#22c55e' : '#64748b'
  );

  // 2. Fullscreen
  const fsY = startY + 92;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
  drawRoundRect(ctx, GAME_W / 2 - cW / 2, fsY, cW, 76, 12);
  ctx.fill();
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('Display Fullscreen', GAME_W / 2 - cW / 2 + 24, fsY + 32);
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText('Toggle immersive fullscreen on mobile or desktop', GAME_W / 2 - cW / 2 + 24, fsY + 52);

  drawButton(ctx, GAME_W / 2 + cW / 2 - 170, fsY + 16, 146, 44, '⛶ FULLSCREEN', '#f59e0b');

  // 3. Reset Best Records
  const rstY = fsY + 92;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
  drawRoundRect(ctx, GAME_W / 2 - cW / 2, rstY, cW, 76, 12);
  ctx.fill();
  ctx.strokeStyle = '#ef4444';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('Reset Best Records', GAME_W / 2 - cW / 2 + 24, rstY + 32);
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText('Clears high score and distance milestones', GAME_W / 2 - cW / 2 + 24, rstY + 52);

  drawButton(
    ctx,
    GAME_W / 2 + cW / 2 - 170,
    rstY + 16,
    146,
    44,
    resetConfirm ? '⚠️ CONFIRM?' : 'RESET DATA',
    resetConfirm ? '#dc2626' : '#ef4444'
  );

  // Back Button
  drawButton(ctx, GAME_W / 2 - 110, 465, 220, 44, '← MAIN MENU', '#64748b');
  ctx.restore();
}

export function drawPauseScreen(ctx: CanvasRenderingContext2D) {
  ctx.fillStyle = 'rgba(10, 16, 30, 0.78)';
  ctx.fillRect(0, 0, GAME_W, GAME_H);

  ctx.save();
  ctx.textAlign = 'center';

  ctx.font = '900 44px system-ui, sans-serif';
  ctx.fillStyle = '#f8fafc';
  ctx.fillText('PAUSED', GAME_W / 2, 140);

  drawButton(ctx, GAME_W / 2 - 120, 185, 240, 48, '▶ RESUME', '#22c55e');
  drawButton(ctx, GAME_W / 2 - 120, 245, 240, 44, '📖 HOW TO PLAY', '#3b82f6');
  drawButton(ctx, GAME_W / 2 - 120, 301, 240, 44, '🔄 RESTART', '#f59e0b');
  drawButton(ctx, GAME_W / 2 - 120, 357, 240, 44, '🏠 MAIN MENU', '#64748b');

  ctx.font = '13px system-ui, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText('Press [P] to quick resume or [R] to restart', GAME_W / 2, 435);
  ctx.restore();
}

export function drawGameOverScreen(
  ctx: CanvasRenderingContext2D,
  player: Player,
  runStats?: RunStats,
  coinBalance: number = 0
) {
  ctx.fillStyle = 'rgba(15, 5, 10, 0.88)';
  ctx.fillRect(0, 0, GAME_W, GAME_H);

  ctx.save();
  ctx.textAlign = 'center';

  ctx.font = '900 50px system-ui, sans-serif';
  ctx.fillStyle = '#ef4444';
  ctx.fillText('RUN FINISHED', GAME_W / 2, 125);

  const isNewBest = runStats && Math.floor(player.distance) >= runStats.bestDistance && player.distance > 50;

  if (isNewBest) {
    ctx.font = 'bold 14px system-ui, sans-serif';
    ctx.fillStyle = '#fde047';
    ctx.fillText('★ NEW DISTANCE RECORD! ★', GAME_W / 2, 156);
  }

  // Stats Card
  const cW = 500;
  const cH = 90;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
  drawRoundRect(ctx, GAME_W / 2 - cW / 2, 172, cW, cH, 12);
  ctx.fill();
  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.font = 'bold 19px system-ui, sans-serif';
  ctx.fillStyle = '#38bdf8';
  ctx.fillText(`Distance: ${Math.floor(player.distance).toLocaleString()}m`, GAME_W / 2 - 120, 210);

  ctx.fillStyle = '#fde047';
  ctx.fillText(`Score: ${player.score.toLocaleString()}`, GAME_W / 2 + 120, 210);

  ctx.font = '500 14px system-ui, sans-serif';
  ctx.fillStyle = '#cbd5e1';
  ctx.fillText(
    `Run Coins: +${player.coins}   •   Total Bank: ${coinBalance.toLocaleString()} 🪙   •   Time: ${Math.floor(player.timeElapsed)}s`,
    GAME_W / 2,
    242
  );

  // 3 Action Buttons
  drawButton(ctx, GAME_W / 2 - 130, 282, 260, 48, '🔄 TRY AGAIN (R)', '#22c55e');
  drawButton(ctx, GAME_W / 2 - 130, 340, 260, 44, '🛒 UPGRADE SHOP', '#f59e0b');
  drawButton(ctx, GAME_W / 2 - 130, 396, 260, 44, '🏠 MAIN MENU', '#64748b');
  ctx.restore();
}

export function drawVictoryScreen(ctx: CanvasRenderingContext2D, player: Player, coinBalance: number = 0) {
  ctx.fillStyle = 'rgba(5, 20, 30, 0.9)';
  ctx.fillRect(0, 0, GAME_W, GAME_H);

  ctx.save();
  ctx.textAlign = 'center';

  const pulse = Math.sin(performance.now() * 0.005) * 4;
  ctx.font = '900 50px system-ui, sans-serif';
  ctx.fillStyle = '#facc15';
  ctx.fillText('STAGE CLEARED!', GAME_W / 2, 120 + pulse);

  ctx.font = '700 18px system-ui, sans-serif';
  ctx.fillStyle = '#38bdf8';
  ctx.fillText('Congratulations! Jiro conquered the course!', GAME_W / 2, 160);

  ctx.fillStyle = '#1e293b';
  drawRoundRect(ctx, GAME_W / 2 - 220, 185, 440, 140, 12);
  ctx.fill();
  ctx.strokeStyle = '#334155';
  ctx.stroke();

  const mins = Math.floor(player.timeElapsed / 60);
  const secs = Math.floor(player.timeElapsed % 60);
  const timeStr = `${mins}m ${secs}s`;

  ctx.font = '15px system-ui, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText(`Clear Time: ${timeStr}`, GAME_W / 2, 220);
  ctx.fillText(`Coins Collected: +${player.coins} (+${player.coins * 100} pts)`, GAME_W / 2, 252);

  ctx.font = 'bold 22px system-ui, sans-serif';
  ctx.fillStyle = '#22c55e';
  ctx.fillText(`TOTAL SCORE: ${player.score.toLocaleString()}`, GAME_W / 2, 296);

  drawButton(ctx, GAME_W / 2 - 130, 345, 260, 48, '★ PLAY AGAIN (R)', '#22c55e');
  drawButton(ctx, GAME_W / 2 - 130, 403, 260, 44, '🛒 UPGRADE SHOP', '#f59e0b');
  drawButton(ctx, GAME_W / 2 - 130, 457, 260, 42, '🏠 MAIN MENU', '#64748b');
  ctx.restore();
}
