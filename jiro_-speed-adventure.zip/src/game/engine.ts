import { GameState, Player, Platform, Spring, Checkpoint, Coin, Enemy, Particle, SceneryItem, FinishFlag, PowerUp, GameNotification, Boss, RunStats } from '../types';
import { createInitialWorld, generateNextChunk, cleanOldEntities, WorldData, LEVEL_HEIGHT } from './level';
import { sound } from './audio';
import {
  GAME_W,
  GAME_H,
  drawBackground,
  drawPlatforms,
  drawCheckpoints,
  drawFinishFlag,
  drawCoins,
  drawPowerUps,
  drawEnemies,
  drawBoss,
  drawJiro,
  renderParticles,
  drawHUD,
  drawStartScreen,
  drawControlsScreen,
  drawPauseScreen,
  drawGameOverScreen,
  drawVictoryScreen
} from './renderer';

export class GameEngine {
  public state: GameState = 'start';
  public player!: Player;
  public world!: WorldData;
  public platforms: Platform[] = [];
  public springs: Spring[] = [];
  public checkpoints: Checkpoint[] = [];
  public coins: Coin[] = [];
  public powerups: PowerUp[] = [];
  public notifications: GameNotification[] = [];
  public enemies: Enemy[] = [];
  public hills: SceneryItem[] = [];
  public trees: SceneryItem[] = [];
  public clouds: SceneryItem[] = [];
  public finishFlag!: FinishFlag;
  public particles: Particle[] = [];
  public boss!: Boss;
  public runStats: RunStats = { bestScore: 0, bestDistance: 0, bestCoins: 0, totalRuns: 0 };
  public nextBossDistance: number = 450;
  public lastMilestone: number = 0;
  private cleanTimer: number = 0;

  public camera = { x: 0, targetX: 0 };
  public keys = { left: false, right: false, jump: false, jumpBuffered: false };

  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private animFrameId: number | null = null;
  private lastTime: number = performance.now();

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.loadStats();
    this.resetGame();
  }

  private loadStats() {
    try {
      const saved = localStorage.getItem('jiro_speed_adventure_stats');
      if (saved) {
        this.runStats = JSON.parse(saved);
      }
    } catch {
      // Ignore local storage error in iframe sandbox if restricted
    }
  }

  public saveStats() {
    if (!this.player) return;
    this.runStats.totalRuns++;
    if (this.player.score > this.runStats.bestScore) this.runStats.bestScore = this.player.score;
    const currentDist = Math.floor(this.player.distance);
    if (currentDist > this.runStats.bestDistance) this.runStats.bestDistance = currentDist;
    if (this.player.coins > this.runStats.bestCoins) this.runStats.bestCoins = this.player.coins;

    try {
      localStorage.setItem('jiro_speed_adventure_stats', JSON.stringify(this.runStats));
    } catch {
      // Ignore local storage error
    }
  }

  private syncWorldEntities() {
    this.platforms = this.world.platforms;
    this.springs = this.world.springs;
    this.checkpoints = this.world.checkpoints;
    this.coins = this.world.coins;
    this.powerups = this.world.powerups;
    this.enemies = this.world.enemies;
    this.hills = this.world.hills;
    this.trees = this.world.trees;
    this.clouds = this.world.clouds;
  }

  public showNotification(text: string, subtext?: string, color = '#38bdf8', duration = 2.4) {
    this.notifications.push({
      text,
      subtext,
      color,
      timer: duration,
      maxTimer: duration,
      y: 90
    });
  }

  public collectPowerUp(pow: PowerUp) {
    pow.collected = true;
    const p = this.player;

    if (pow.type === 'speed') {
      p.speedBoostTimer = 7.0;
      p.maxSpeed = 12.0;
      p.accel = 0.95;
      p.score += 200;
      sound.playPowerUp();
      this.showNotification('⚡ SPEED BOOST!', '+40% Max Velocity for 7s', '#facc15');
      this.spawnConfetti(pow.x + pow.width / 2, pow.y + pow.height / 2, 14);
    } else if (pow.type === 'shield') {
      p.shield = true;
      p.score += 200;
      sound.playShield();
      this.showNotification('🛡️ SHIELD ACTIVE!', 'Protected from 1 enemy hit', '#38bdf8');
      this.spawnConfetti(pow.x + pow.width / 2, pow.y + pow.height / 2, 14);
    } else if (pow.type === 'life') {
      sound.playExtraLife();
      if (p.lives < 5) {
        p.lives++;
        this.showNotification('❤️ EXTRA LIFE!', `+1 Life (Total: ${p.lives}/5)`, '#f43f5e');
      } else {
        p.score += 500;
        this.showNotification('❤️ LIFE BONUS!', '+500 Points (Max Lives)', '#f43f5e');
      }
      this.spawnConfetti(pow.x + pow.width / 2, pow.y + pow.height / 2, 14);
    } else if (pow.type === 'magnet') {
      p.coinMagnetTimer = 8.0;
      p.score += 200;
      sound.playPowerUp();
      this.showNotification('🧲 COIN MAGNET!', 'Attracting nearby coins for 8s', '#c084fc');
      this.spawnConfetti(pow.x + pow.width / 2, pow.y + pow.height / 2, 14);
    } else if (pow.type === 'jump') {
      p.superJumpTimer = 7.0;
      p.jumpForce = -15.8;
      p.score += 200;
      sound.playPowerUp();
      this.showNotification('🔥 SUPER JUMP!', 'Higher jump & air control for 7s', '#fb923c');
      this.spawnConfetti(pow.x + pow.width / 2, pow.y + pow.height / 2, 14);
    }
  }

  public resetGame() {
    this.player = {
      x: 100,
      y: 350,
      width: 32,
      height: 42,
      vx: 0,
      vy: 0,
      accel: 0.65,
      friction: 0.84,
      maxSpeed: 7.8,
      gravity: 0.52,
      jumpForce: -12.4,
      isGrounded: false,
      facingRight: true,
      runFrame: 0,
      invulnerableTimer: 0,
      coyoteTimer: 0,
      jumpBufferTimer: 0,
      lives: 3,
      score: 0,
      coins: 0,
      distance: 0,
      timeElapsed: 0,
      respawnX: 100,
      respawnY: 350,
      speedBoostTimer: 0,
      shield: false,
      coinMagnetTimer: 0,
      superJumpTimer: 0
    };

    this.world = createInitialWorld();
    this.syncWorldEntities();
    this.notifications = [];
    this.finishFlag = { x: -9999, y: -9999, width: 36, height: 90, reached: false };
    this.particles = [];
    this.camera.x = 0;
    this.nextBossDistance = 450;
    this.lastMilestone = 0;
    this.cleanTimer = 0;

    this.boss = {
      active: false,
      x: 0,
      y: 350,
      width: 86,
      height: 76,
      vx: 0,
      vy: 0,
      health: 3,
      maxHealth: 3,
      animFrame: 0,
      state: 'idle',
      warningTimer: 0,
      name: 'Gorgonix Behemoth',
      chaseDistance: 0,
      escapeGoal: 220,
      hitCooldown: 0
    };
  }

  public respawnPlayer() {
    this.player.x = this.player.respawnX;
    this.player.y = this.player.respawnY;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.invulnerableTimer = 90;
    // Clear active power-ups on respawn
    this.player.speedBoostTimer = 0;
    this.player.shield = false;
    this.player.coinMagnetTimer = 0;
    this.player.superJumpTimer = 0;
    this.player.maxSpeed = 7.8;
    this.player.jumpForce = -12.4;
    this.player.accel = 0.65;
    sound.playHurt();
  }

  public spawnDust(x: number, y: number, count = 5, color = 'rgba(255, 255, 255, 0.7)') {
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: x + (Math.random() - 0.5) * 12,
        y: y,
        vx: (Math.random() - 0.5) * 3,
        vy: -Math.random() * 2 - 0.5,
        radius: Math.random() * 3 + 2,
        alpha: 1,
        color: color,
        decay: Math.random() * 0.03 + 0.02
      });
    }
  }

  public spawnCoinSparkle(x: number, y: number) {
    for (let i = 0; i < 8; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 4 + 1.5;
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: Math.random() * 3 + 2,
        alpha: 1,
        color: '#ffd700',
        decay: 0.03
      });
    }
  }

  public spawnConfetti(x: number, y: number, count = 20) {
    const colors = ['#ff3b30', '#ff9500', '#ffcc00', '#34c759', '#007aff', '#af52de'];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 6 + 2;
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 3,
        radius: Math.random() * 4 + 2,
        alpha: 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        decay: 0.015
      });
    }
  }

  public update(dt: number) {
    if (this.state !== 'playing') return;

    const p = this.player;
    p.timeElapsed += dt;

    // Horizontal Input
    if (this.keys.left) {
      p.vx -= p.accel;
      p.facingRight = false;
    } else if (this.keys.right) {
      p.vx += p.accel;
      p.facingRight = true;
    } else {
      p.vx *= p.friction;
      if (Math.abs(p.vx) < 0.1) p.vx = 0;
    }

    // Clamp speed
    if (p.vx > p.maxSpeed) p.vx = p.maxSpeed;
    if (p.vx < -p.maxSpeed) p.vx = -p.maxSpeed;

    // Running dust
    if (p.isGrounded && Math.abs(p.vx) > 3.5 && Math.random() < 0.25) {
      this.spawnDust(p.x + p.width / 2, p.y + p.height, 2, 'rgba(230, 240, 255, 0.6)');
    }

    // Speed boost particle trail
    if (p.speedBoostTimer > 0 && Math.abs(p.vx) > 3 && Math.random() < 0.4) {
      this.spawnDust(p.x + (p.facingRight ? 2 : p.width - 2), p.y + p.height - 6, 2, '#fde047');
    }

    // Super jump foot flame trail when airborne
    if (p.superJumpTimer > 0 && !p.isGrounded && Math.random() < 0.3) {
      this.spawnDust(p.x + p.width / 2 + (Math.random() - 0.5) * 8, p.y + p.height - 2, 1, '#fb923c');
    }

    // --- POWER-UP TIMERS & EXPIRATION ---
    if (p.speedBoostTimer > 0) {
      p.speedBoostTimer -= dt;
      if (p.speedBoostTimer <= 0) {
        p.speedBoostTimer = 0;
        p.maxSpeed = 7.8;
        p.accel = 0.65;
        sound.playPowerExpire();
      }
    }

    if (p.coinMagnetTimer > 0) {
      p.coinMagnetTimer -= dt;
      if (p.coinMagnetTimer <= 0) {
        p.coinMagnetTimer = 0;
        sound.playPowerExpire();
      }
    }

    if (p.superJumpTimer > 0) {
      p.superJumpTimer -= dt;
      if (p.superJumpTimer <= 0) {
        p.superJumpTimer = 0;
        p.jumpForce = -12.4;
        sound.playPowerExpire();
      }
    }

    // --- NOTIFICATION TIMERS ---
    for (let i = this.notifications.length - 1; i >= 0; i--) {
      const n = this.notifications[i];
      n.timer -= dt;
      n.y -= dt * 10;
      if (n.timer <= 0) {
        this.notifications.splice(i, 1);
      }
    }

    // Jump Buffering & Coyote Time
    if (p.isGrounded) {
      p.coyoteTimer = 6;
    } else {
      if (p.coyoteTimer > 0) p.coyoteTimer--;
    }

    if (this.keys.jumpBuffered) {
      p.jumpBufferTimer = 6;
      this.keys.jumpBuffered = false;
    } else {
      if (p.jumpBufferTimer > 0) p.jumpBufferTimer--;
    }

    if (p.jumpBufferTimer > 0 && p.coyoteTimer > 0) {
      p.vy = p.jumpForce;
      p.isGrounded = false;
      p.coyoteTimer = 0;
      p.jumpBufferTimer = 0;
      sound.playJump();
      this.spawnDust(p.x + p.width / 2, p.y + p.height, 6);
    }

    // Gravity
    p.vy += p.gravity;
    if (p.vy > 14) p.vy = 14;

    // Moving platforms
    this.platforms.forEach(plat => {
      if (plat.moving && plat.range && plat.dir && plat.speed && plat.originX !== undefined) {
        plat.x += plat.speed * plat.dir;
        if (plat.x > plat.originX + plat.range) {
          plat.x = plat.originX + plat.range;
          plat.dir = -1;
        } else if (plat.x < plat.originX - plat.range) {
          plat.x = plat.originX - plat.range;
          plat.dir = 1;
        }
      }
    });

    // Horizontal Movement & Wall Collision
    p.x += p.vx;
    for (const plat of this.platforms) {
      if (plat.type === 'ground') {
        if (
          p.x < plat.x + plat.width &&
          p.x + p.width > plat.x &&
          p.y < plat.y + plat.height &&
          p.y + p.height > plat.y + 10
        ) {
          if (p.vx > 0) {
            p.x = plat.x - p.width;
            p.vx = 0;
          } else if (p.vx < 0) {
            p.x = plat.x + plat.width;
            p.vx = 0;
          }
        }
      }
    }

    // Vertical Movement & Platform Landing
    p.y += p.vy;
    p.isGrounded = false;

    for (const plat of this.platforms) {
      const overlapX = p.x + p.width > plat.x + 4 && p.x < plat.x + plat.width - 4;
      if (overlapX) {
        const prevBottom = p.y + p.height - p.vy;
        if (prevBottom <= plat.y + 8 && p.y + p.height >= plat.y) {
          p.y = plat.y - p.height;
          p.vy = 0;
          p.isGrounded = true;
          if (plat.moving && plat.speed && plat.dir) {
            p.x += plat.speed * plat.dir;
          }
        } else if (plat.type === 'ground' && p.vy < 0 && p.y <= plat.y + plat.height && p.y - p.vy >= plat.y + plat.height - 8) {
          p.y = plat.y + plat.height;
          p.vy = 0;
        }
      }
    }

    // Springs
    this.springs.forEach(s => {
      if (
        p.x + p.width > s.x &&
        p.x < s.x + s.width &&
        p.y + p.height >= s.y &&
        p.y + p.height <= s.y + s.height + 12 &&
        p.vy >= 0
      ) {
        p.vy = s.power;
        p.isGrounded = false;
        sound.playJump();
        this.spawnDust(s.x + s.width / 2, s.y + s.height, 10, '#ff9500');
      }
    });

    // Checkpoints
    this.checkpoints.forEach(cp => {
      if (!cp.reached && Math.abs(p.x - cp.x) < 40 && Math.abs(p.y - cp.y) < 70) {
        cp.reached = true;
        p.respawnX = cp.x;
        p.respawnY = cp.y;
        sound.playCheckpoint();
        this.spawnConfetti(cp.x, cp.y - 40, 15);
      }
    });

    // Coins
    this.coins.forEach(c => {
      if (!c.collected) {
        // Coin Magnet Pull
        if (p.coinMagnetTimer > 0) {
          const px = p.x + p.width / 2;
          const py = p.y + p.height / 2;
          const mDist = Math.hypot(px - c.x, py - c.y);
          if (mDist < 240 && mDist > 4) {
            c.x += (px - c.x) * 0.12;
            c.y += (py - c.y) * 0.12;
          }
        }

        const dx = (p.x + p.width / 2) - c.x;
        const dy = (p.y + p.height / 2) - c.y;
        if (Math.hypot(dx, dy) < 26) {
          c.collected = true;
          p.coins++;
          p.score += 100;
          sound.playCoin();
          this.spawnCoinSparkle(c.x, c.y);
        }
      }
    });

    // Power-Ups Collection
    this.powerups.forEach(pow => {
      if (!pow.collected) {
        const dx = (p.x + p.width / 2) - (pow.x + pow.width / 2);
        const dy = (p.y + p.height / 2) - (pow.y + pow.height / 2);
        if (Math.hypot(dx, dy) < 32) {
          this.collectPowerUp(pow);
        }
      }
    });

    // Enemies
    this.enemies.forEach(e => {
      if (!e.alive) {
        if (e.squishTimer > 0) e.squishTimer--;
        return;
      }

      e.animFrame += 0.1;
      if (e.type === 'bumble') {
        e.y = e.originY + Math.sin(e.animFrame) * 22;
        e.x += e.vx;
      } else {
        e.x += e.vx;
      }

      if (e.x < e.minX) {
        e.x = e.minX;
        e.vx = Math.abs(e.vx);
      } else if (e.x > e.maxX) {
        e.x = e.maxX;
        e.vx = -Math.abs(e.vx);
      }

      const playerBottom = p.y + p.height;
      const enemyTop = e.y;
      const isOverlapX = p.x + p.width > e.x && p.x < e.x + e.width;
      const isOverlapY = p.y + p.height > e.y && p.y < e.y + e.height;

      if (isOverlapX && isOverlapY) {
        const isStomp = p.vy > 0 && playerBottom - p.vy <= enemyTop + 14;
        if (isStomp) {
          e.alive = false;
          e.squishTimer = 20;
          p.vy = -9.2;
          p.score += 250;
          sound.playDefeat();
          this.spawnDust(e.x + e.width / 2, e.y + e.height / 2, 8, '#ffcc00');
        } else if (p.shield) {
          // Shield absorbs the blow!
          p.shield = false;
          p.invulnerableTimer = 60;
          p.vy = -6;
          p.vx = p.facingRight ? -4 : 4;
          sound.playShieldBreak();
          this.spawnDust(p.x + p.width / 2, p.y + p.height / 2, 16, '#38bdf8');
          this.showNotification('🛡️ SHIELD BROKEN!', 'Protected you from damage', '#38bdf8', 2.0);
        } else if (p.invulnerableTimer <= 0) {
          p.lives--;
          if (p.lives <= 0) {
            sound.playHurt();
            this.state = 'gameover';
            this.saveStats();
          } else {
            p.invulnerableTimer = 90;
            p.vy = -6;
            p.vx = p.facingRight ? -5 : 5;
            sound.playHurt();
          }
        }
      }
    });

    // Invulnerability
    if (p.invulnerableTimer > 0) {
      p.invulnerableTimer--;
    }

    // Distance progression & score calculation
    const curDist = Math.max(0, (p.x - 100) / 22);
    if (curDist > p.distance) {
      const distDiff = curDist - p.distance;
      p.distance = curDist;
      p.score += Math.floor(distDiff * 2.5);
    }

    // 100m Milestone Audio & Bonus Notifications
    const m100 = Math.floor(p.distance / 100) * 100;
    if (m100 > this.lastMilestone && m100 > 0) {
      this.lastMilestone = m100;
      sound.playMilestone();
      this.showNotification(`🚩 MILESTONE: ${m100}m REACHED!`, '+250 Milestone Points', '#38bdf8', 2.5);
      p.score += 250;
    }

    // Procedural Endless Generation Chunk Trigger
    if (p.x + 1600 > this.world.nextGenX) {
      generateNextChunk(this.world, p.distance);
      this.syncWorldEntities();
    }

    // Periodic Cleanup of Far-Left Entities
    this.cleanTimer += dt;
    if (this.cleanTimer > 4.0) {
      this.cleanTimer = 0;
      cleanOldEntities(this.world, this.camera.x - 800);
      this.syncWorldEntities();
    }

    // --- BOSS ENCOUNTER SYSTEM ("Gorgonix Behemoth") ---
    if (!this.boss.active && p.distance >= this.nextBossDistance) {
      this.boss.active = true;
      this.boss.state = 'warning';
      this.boss.warningTimer = 2.8;
      this.boss.health = 3;
      this.boss.chaseDistance = 0;
      this.boss.escapeGoal = 200 + Math.min(250, Math.floor(p.distance / 200) * 40);
      this.boss.x = p.x - 280;
      this.boss.y = 350;
      sound.playBossWarning();
      this.showNotification('⚠️ BOSS WARNING: GORGONIX!', 'The Behemoth approaches! Stomp head gem or flee!', '#ef4444', 3.0);
    }

    if (this.boss.active) {
      const b = this.boss;
      if (b.state === 'warning') {
        b.warningTimer -= dt;
        if (b.warningTimer <= 0) {
          b.state = 'chasing';
          b.x = p.x - 260;
          b.y = p.y - 20;
          sound.playBossRoar();
          this.showNotification('💥 GORGONIX APPEARS!', 'Escape forward or crush its glowing head gem!', '#f97316', 2.8);
        }
      } else if (b.state === 'chasing') {
        if (b.hitCooldown > 0) b.hitCooldown -= dt;

        // Dynamic chase speed matching difficulty tier
        const baseSpeed = 6.4 + Math.min(3.8, p.distance / 300);
        b.vx = baseSpeed;
        if (p.x - b.x > 380) {
          b.vx += 1.8;
        } else if (p.x - b.x < 120) {
          b.vx = Math.max(3.5, b.vx - 1.2);
        }
        b.x += b.vx;

        // Boss ground landing & gravity
        b.vy += 0.52;
        b.y += b.vy;
        for (const plat of this.platforms) {
          if (b.x + b.width > plat.x && b.x < plat.x + plat.width) {
            if (b.y + b.height >= plat.y && b.y + b.height - b.vy <= plat.y + 18) {
              b.y = plat.y - b.height;
              b.vy = 0;
            }
          }
        }

        // Track escape progress
        b.chaseDistance += (b.vx * dt) * 0.85;

        // Check Escape Success
        if (b.chaseDistance >= b.escapeGoal) {
          b.state = 'escaped';
          b.active = false;
          sound.playEscapeSuccess();
          p.score += 1500;
          p.coins += 10;
          this.nextBossDistance = p.distance + 500;
          this.saveStats();
          this.showNotification('🏃 BOSS ESCAPED!', '+1,500 Escape Bonus & 10 Coins!', '#22c55e', 3.5);
        }

        // Collision with Player
        const overlapX = p.x + p.width > b.x + 8 && p.x < b.x + b.width - 8;
        const overlapY = p.y + p.height > b.y && p.y < b.y + b.height;
        if (overlapX && overlapY) {
          const isHeadStomp = p.vy > 0 && (p.y + p.height - p.vy) <= b.y + 24;
          if (isHeadStomp && b.hitCooldown <= 0) {
            b.health--;
            b.hitCooldown = 0.6;
            p.vy = -12.8;
            sound.playEnemyHit();
            this.spawnDust(b.x + b.width / 2, b.y, 16, '#f43f5e');
            if (b.health <= 0) {
              b.state = 'defeated';
              b.active = false;
              sound.playBossDefeated();
              p.score += 3000;
              p.coins += 25;
              this.spawnConfetti(b.x + b.width / 2, b.y + b.height / 2, 40);
              this.nextBossDistance = p.distance + 600;
              this.saveStats();
              this.showNotification('👑 GORGONIX DEFEATED!', '+3,000 pts & 25 Coins Earned!', '#facc15', 4.0);
            } else {
              this.showNotification(`💎 HEAD STOMP! (${b.health}/${b.maxHealth})`, 'Stomp again to defeat!', '#facc15', 1.5);
            }
          } else if (b.hitCooldown <= 0) {
            if (p.shield) {
              p.shield = false;
              p.invulnerableTimer = 60;
              p.vy = -6;
              p.vx = 8;
              sound.playShieldBreak();
              this.spawnDust(p.x + p.width / 2, p.y + p.height / 2, 16, '#38bdf8');
              this.showNotification('🛡️ SHIELD BROKEN!', 'Saved you from Boss attack!', '#38bdf8', 2.0);
            } else if (p.invulnerableTimer <= 0) {
              p.lives--;
              if (p.lives <= 0) {
                sound.playHurt();
                this.state = 'gameover';
                this.saveStats();
              } else {
                p.invulnerableTimer = 90;
                p.vy = -6;
                p.vx = 8;
                sound.playHurt();
              }
            }
          }
        }
      }
    }

    // Gap pitfall
    if (p.y > LEVEL_HEIGHT + 100) {
      p.lives--;
      if (p.lives <= 0) {
        sound.playHurt();
        this.state = 'gameover';
        this.saveStats();
      } else {
        this.respawnPlayer();
      }
    }

    // Camera follow in infinite world
    this.camera.targetX = p.x - GAME_W * 0.35;
    if (this.camera.targetX < 0) this.camera.targetX = 0;
    this.camera.x += (this.camera.targetX - this.camera.x) * 0.1;

    // Particles update
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const part = this.particles[i];
      part.x += part.vx;
      part.y += part.vy;
      part.vy += 0.1;
      part.alpha -= part.decay;
      if (part.alpha <= 0) {
        this.particles.splice(i, 1);
      }
    }

    // Clouds drift
    this.clouds.forEach(c => {
      c.x += c.speed || 0.2;
      if (c.x > this.camera.x + GAME_W + 300) c.x = this.camera.x - 300;
    });
  }

  public render() {
    this.ctx.clearRect(0, 0, GAME_W, GAME_H);

    drawBackground(this.ctx, this.camera.x, this.clouds, this.hills, this.trees);
    drawCheckpoints(this.ctx, this.camera.x, this.checkpoints);
    drawPlatforms(this.ctx, this.camera.x, this.platforms, this.springs);
    drawCoins(this.ctx, this.camera.x, this.coins);
    drawPowerUps(this.ctx, this.camera.x, this.powerups, this.platforms);
    drawEnemies(this.ctx, this.camera.x, this.enemies, this.platforms);
    drawBoss(this.ctx, this.camera.x, this.boss);
    drawJiro(this.ctx, this.camera.x, this.player, this.platforms);
    renderParticles(this.ctx, this.camera.x, this.particles);

    if (this.state === 'playing' || this.state === 'paused') {
      drawHUD(this.ctx, this.player, this.notifications, this.boss);
    }

    if (this.state === 'start') drawStartScreen(this.ctx, this.runStats);
    else if (this.state === 'controls') drawControlsScreen(this.ctx);
    else if (this.state === 'paused') drawPauseScreen(this.ctx);
    else if (this.state === 'gameover') drawGameOverScreen(this.ctx, this.player, this.runStats);
    else if (this.state === 'victory') drawVictoryScreen(this.ctx, this.player);
  }

  public handleCanvasClick(mx: number, my: number) {
    sound.init();
    const inBox = (bx: number, by: number, bw: number, bh: number) =>
      mx >= bx && mx <= bx + bw && my >= by && my <= by + bh;

    if (this.state === 'start') {
      if (inBox(GAME_W / 2 - 130, 330, 260, 52)) {
        this.resetGame();
        this.state = 'playing';
      } else if (inBox(GAME_W / 2 - 130, 400, 260, 48)) {
        this.state = 'controls';
      }
    } else if (this.state === 'controls') {
      if (inBox(GAME_W / 2 - 100, 475, 200, 44)) {
        this.state = 'start';
      }
    } else if (this.state === 'paused') {
      if (inBox(GAME_W / 2 - 120, 220, 240, 50)) {
        this.state = 'playing';
      } else if (inBox(GAME_W / 2 - 120, 285, 240, 46)) {
        this.state = 'controls';
      } else if (inBox(GAME_W / 2 - 120, 345, 240, 46)) {
        this.resetGame();
        this.state = 'playing';
      }
    } else if (this.state === 'gameover') {
      if (inBox(GAME_W / 2 - 130, 270, 260, 54)) {
        this.resetGame();
        this.state = 'playing';
      } else if (inBox(GAME_W / 2 - 130, 340, 260, 48)) {
        this.state = 'start';
      }
    } else if (this.state === 'victory') {
      if (inBox(GAME_W / 2 - 130, 370, 260, 52)) {
        this.resetGame();
        this.state = 'playing';
      } else if (inBox(GAME_W / 2 - 130, 435, 260, 46)) {
        this.state = 'start';
      }
    }
  }

  public start() {
    this.lastTime = performance.now();
    const loop = (currentTime: number) => {
      const dt = Math.min((currentTime - this.lastTime) / 1000, 0.05);
      this.lastTime = currentTime;

      this.update(dt);
      this.render();

      this.animFrameId = requestAnimationFrame(loop);
    };
    this.animFrameId = requestAnimationFrame(loop);
  }

  public stop() {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
  }
}
