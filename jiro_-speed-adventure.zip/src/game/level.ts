import { Platform, Spring, Checkpoint, Coin, Enemy, SceneryItem, PowerUp, EnemyType, PowerUpType, NPC, NPCType } from '../types';

export const LEVEL_HEIGHT = 650;

export interface WorldData {
  platforms: Platform[];
  springs: Spring[];
  checkpoints: Checkpoint[];
  coins: Coin[];
  powerups: PowerUp[];
  enemies: Enemy[];
  npcs: NPC[];
  hills: SceneryItem[];
  trees: SceneryItem[];
  clouds: SceneryItem[];
  nextGenX: number;
  lastCheckpointDistance: number;
  nextPowerupId: number;
  nextCheckpointId: number;
}

// Helpers for chunk generation
let powerupCounter = 1;
let checkpointCounter = 1;
let npcCounter = 1;

export function createInitialWorld(): WorldData {
  powerupCounter = 1;
  checkpointCounter = 1;
  npcCounter = 1;

  const world: WorldData = {
    platforms: [],
    springs: [],
    checkpoints: [],
    coins: [],
    powerups: [],
    enemies: [],
    npcs: [],
    hills: [],
    trees: [],
    clouds: [],
    nextGenX: 0,
    lastCheckpointDistance: 0,
    nextPowerupId: 1,
    nextCheckpointId: 1
  };

  // Initial clouds across the starting sky
  for (let x = -200; x < 2400; x += 320) {
    world.clouds.push({
      x: x + Math.random() * 80,
      y: 50 + Math.random() * 110,
      width: 90 + Math.random() * 70,
      height: 36 + Math.random() * 16,
      speed: 0.15 + Math.random() * 0.15
    });
  }

  // Generate safe starting tutorial plains
  generateStartingSection(world);

  // Generate initial forward buffer
  while (world.nextGenX < 3200) {
    generateNextChunk(world, 0);
  }

  return world;
}

function addGround(world: WorldData, x: number, w: number, y = 470, h = 180) {
  world.platforms.push({ x, y, width: w, height: h, type: 'ground' });
  // Add background scenery along this ground
  const numTrees = Math.floor(w / 260);
  for (let i = 0; i < numTrees; i++) {
    if (Math.random() > 0.25) {
      world.trees.push({
        x: x + 60 + i * 240 + (Math.random() - 0.5) * 40,
        y: y,
        height: 65 + Math.random() * 45,
        type: Math.floor(Math.random() * 2)
      });
    }
  }

  // Hills behind
  const numHills = Math.floor(w / 300);
  for (let i = 0; i < numHills; i++) {
    world.hills.push({
      x: x + 80 + i * 290 + (Math.random() - 0.5) * 50,
      y: y + 20,
      radius: 170 + Math.random() * 80,
      color: Math.random() > 0.5 ? '#73c36b' : '#64b65c'
    });
  }
}

function addPlatform(world: WorldData, x: number, y: number, w: number, h = 22, moving = false, range = 0) {
  world.platforms.push({
    x, y, width: w, height: h,
    type: 'platform',
    moving,
    originX: x,
    originY: y,
    range,
    dir: 1,
    speed: 1.2
  });
}

function addCoinRow(world: WorldData, startX: number, y: number, count: number, spacing = 36) {
  for (let i = 0; i < count; i++) {
    world.coins.push({
      x: startX + i * spacing,
      y,
      collected: false,
      animOffset: Math.random() * Math.PI * 2
    });
  }
}

function addCoinArc(world: WorldData, startX: number, baseY: number, count = 5, span = 180, height = 48) {
  for (let i = 0; i < count; i++) {
    const t = i / (count - 1);
    const cx = startX + t * span;
    const cy = baseY - Math.sin(t * Math.PI) * height;
    world.coins.push({
      x: cx,
      y: cy,
      collected: false,
      animOffset: t * 2
    });
  }
}

function addPowerUp(world: WorldData, type: PowerUpType, x: number, y: number) {
  world.powerups.push({
    id: powerupCounter++,
    type,
    x,
    y,
    width: 28,
    height: 28,
    collected: false,
    animOffset: Math.random() * Math.PI * 2
  });
}

function addNPC(
  world: WorldData,
  type: NPCType,
  x: number,
  y: number,
  dialogue: string,
  name: string,
  pointedDirection?: 'up' | 'right' | 'up-right'
) {
  world.npcs.push({
    id: npcCounter++,
    type,
    x,
    y,
    width: type === 'bolt' ? 24 : 26,
    height: type === 'bolt' ? 26 : 38,
    dialogue,
    name,
    animTimer: Math.random() * Math.PI * 2,
    facingRight: true,
    pointedDirection
  });
}

function addEnemy(world: WorldData, type: EnemyType, x: number, y: number, minX: number, maxX: number, speed = 1.3) {
  let w = 32;
  let h = 28;
  if (type === 'bumble') {
    w = 30;
    h = 26;
  } else if (type === 'chonker') {
    w = 40;
    h = 36;
  } else if (type === 'hopper') {
    w = 28;
    h = 30;
  } else if (type === 'starstrider') {
    w = 26;
    h = 42;
  }

  world.enemies.push({
    type,
    x,
    y,
    width: w,
    height: h,
    vx: speed,
    minX,
    maxX,
    alive: true,
    squishTimer: 0,
    animFrame: 0,
    originY: y,
    jumpCooldown: Math.floor(Math.random() * 60) + 40
  });
}

// 1. Initial Starting Meadow (0 to 1400)
function generateStartingSection(world: WorldData) {
  addGround(world, 0, 850);
  addPlatform(world, 340, 380, 110);
  addPlatform(world, 520, 310, 120);

  addCoinRow(world, 240, 430, 4);
  addCoinArc(world, 340, 340, 5, 120, 40);
  addCoinRow(world, 530, 270, 3);
  addPowerUp(world, 'speed', 620, 420);

  // First gentle ground enemy
  addEnemy(world, 'sprout', 480, 442, 380, 780, 1.2);

  // Friendly companion Mira cheering Jiro at the start!
  addNPC(world, 'mira', 370, 342, "Go Jiro! Smash that speed record!", 'Mira');

  // Small Gap 1 (850 to 980) - 130px gap, very easy jump
  addGround(world, 980, 650);
  addPlatform(world, 1080, 370, 110);
  addPlatform(world, 1260, 290, 110);

  // Helper Robot Bolt offering tips near the first jump
  addNPC(world, 'bolt', 1090, 332, "Coins in the sky! Hold Jump for max air!", 'Bolt', 'up-right');

  addCoinArc(world, 840, 430, 5, 150, 50);
  addCoinRow(world, 1050, 430, 3);
  addPowerUp(world, 'shield', 1260, 240);

  addEnemy(world, 'sprout', 1140, 442, 1000, 1450, 1.3);
  addEnemy(world, 'bumble', 1340, 240, 1280, 1460, 1.5);

  world.nextGenX = 1630;
}

// Procedural Chunk Generator: takes current distance and selects from balanced templates
export function generateNextChunk(world: WorldData, currentDistance: number) {
  const startX = world.nextGenX;

  // Determine difficulty tier
  let tier = 0;
  if (currentDistance >= 2500) tier = 4;
  else if (currentDistance >= 1500) tier = 3;
  else if (currentDistance >= 1000) tier = 2;
  else if (currentDistance >= 500) tier = 1;

  // Milestone Checkpoint check: every 700 - 900m
  const shouldPlaceCheckpoint = (currentDistance - world.lastCheckpointDistance >= 700);

  if (shouldPlaceCheckpoint) {
    // Generate a calm milestone rest sanctuary chunk with a Checkpoint!
    const chunkLength = 800;
    addGround(world, startX, chunkLength);

    const cpX = startX + 280;
    const cpY = 470; // Firmly on the ground
    world.checkpoints.push({
      id: checkpointCounter++,
      x: cpX,
      y: cpY,
      reached: false
    });
    world.lastCheckpointDistance = currentDistance;

    // Pleasant reward coins & power-up at checkpoint
    addCoinArc(world, startX + 80, 420, 5, 160, 55);
    addCoinRow(world, startX + 380, 430, 4);

    // Give a useful strategic powerup at the checkpoint
    const pTypes: PowerUpType[] = ['shield', 'life', 'magnet'];
    const pType = pTypes[Math.floor(Math.random() * pTypes.length)];
    addPowerUp(world, pType, startX + 520, 420);

    // Floating scenic ledge
    addPlatform(world, startX + 460, 340, 130);
    addCoinRow(world, startX + 480, 290, 3);

    // Supportive companion or helper robot greeting Jiro at the checkpoint!
    if (Math.random() > 0.45) {
      const miraQuotes = [
        "Awesome run, Jiro! Keep the rhythm!",
        "Checkpoint secured! You're flying!",
        "Looking super fast, Jiro!",
        "Pace yourself! Great momentum!"
      ];
      const q = miraQuotes[Math.floor(Math.random() * miraQuotes.length)];
      addNPC(world, 'mira', startX + 480, 302, q, 'Mira');
    } else {
      const boltQuotes = [
        "Shields absorb one hit without life loss!",
        "Coin Magnet pulls every coin in sight!",
        "Hold Jump on springs for astronomical air!",
        "Scan ahead! Watch out for Gorgonix!"
      ];
      const q = boltQuotes[Math.floor(Math.random() * boltQuotes.length)];
      addNPC(world, 'bolt', startX + 480, 304, q, 'Bolt', 'up-right');
    }

    world.nextGenX = startX + chunkLength;
    return;
  }

  // Regular Procedural Chunks according to tier
  // Pick pattern randomly from the tier's suite
  const patternIndex = Math.floor(Math.random() * 4);

  switch (tier) {
    case 0: // 0 - 500m: Gentle, comfortable introductory terrain
      generateTier0Chunk(world, startX, patternIndex);
      break;
    case 1: // 500 - 1000m: Moderate platforming, gentle gaps, first bumble patrols
      generateTier1Chunk(world, startX, patternIndex);
      break;
    case 2: // 1000 - 1500m: Moving ledges, springboards, crawlers, coin magnets
      generateTier2Chunk(world, startX, patternIndex);
      break;
    case 3: // 1500 - 2500m: Multi-tiered routes, hoppers, chonkers, super jumps
      generateTier3Chunk(world, startX, patternIndex);
      break;
    default: // 2500m+: Advanced sky islands, rapid patrols, starstriders, high rewards
      generateTier4Chunk(world, startX, patternIndex);
      break;
  }
}

// Tier 0: 0 - 500m
function generateTier0Chunk(world: WorldData, startX: number, pattern: number) {
  if (pattern === 0) {
    // Continuous meadow with floating arches
    const len = 750;
    addGround(world, startX, len);
    addPlatform(world, startX + 160, 370, 120);
    addPlatform(world, startX + 360, 290, 120);
    addPlatform(world, startX + 540, 360, 110);

    addCoinRow(world, startX + 80, 430, 3);
    addCoinArc(world, startX + 180, 320, 5, 160, 50);
    addCoinRow(world, startX + 380, 240, 3);

    addEnemy(world, 'sprout', startX + 280, 442, startX + 80, startX + 680, 1.2);
    if (Math.random() < 0.4) addPowerUp(world, 'magnet', startX + 390, 240);

    world.nextGenX = startX + len;
  } else if (pattern === 1) {
    // Two small platforms over a 140px gap
    const g1 = 400;
    const gap = 140;
    const g2 = 450;
    addGround(world, startX, g1);
    addPlatform(world, startX + 220, 360, 110);

    addPlatform(world, startX + g1 + 20, 320, 100); // Safety step over gap
    addGround(world, startX + g1 + gap, g2);

    addCoinArc(world, startX + g1 - 60, 420, 5, gap + 120, 55);
    addCoinRow(world, startX + g1 + gap + 80, 430, 4);

    addEnemy(world, 'sprout', startX + 150, 442, startX + 50, startX + 350, 1.2);
    addEnemy(world, 'bumble', startX + g1 + gap + 160, 280, startX + g1 + gap, startX + g1 + gap + 350, 1.4);

    world.nextGenX = startX + g1 + gap + g2;
  } else if (pattern === 2) {
    // Spring launch over elevated stone steps
    const len = 700;
    addGround(world, startX, len);
    addPlatform(world, startX + 260, 340, 120);
    addPlatform(world, startX + 440, 260, 130);

    world.springs.push({ x: startX + 180, y: 454, width: 34, height: 16, power: -14.5 });
    addCoinArc(world, startX + 180, 420, 6, 220, 85);
    addCoinRow(world, startX + 460, 210, 3);
    addPowerUp(world, 'speed', startX + 480, 210);

    addEnemy(world, 'sprout', startX + 480, 442, startX + 350, startX + 660, 1.3);
    world.nextGenX = startX + len;
  } else {
    // Dual rolling hills with coin cascades
    const len = 800;
    addGround(world, startX, len);
    addPlatform(world, startX + 180, 380, 110);
    addPlatform(world, startX + 340, 310, 130);
    addPlatform(world, startX + 520, 380, 110);

    addCoinRow(world, startX + 60, 430, 3);
    addCoinArc(world, startX + 330, 260, 4, 140, 40);
    addCoinRow(world, startX + 620, 430, 4);

    addEnemy(world, 'sprout', startX + 240, 442, startX + 100, startX + 400, 1.3);
    addEnemy(world, 'sprout', startX + 580, 442, startX + 450, startX + 750, 1.3);

    world.nextGenX = startX + len;
  }
}

// Tier 1: 500 - 1000m
function generateTier1Chunk(world: WorldData, startX: number, pattern: number) {
  if (pattern === 0) {
    // Staggered Canyon with moving ledge
    const g1 = 360;
    const gap = 200;
    const g2 = 420;
    addGround(world, startX, g1);
    addPlatform(world, startX + g1 + 20, 350, 90, 22, true, 50);
    addGround(world, startX + g1 + gap, g2);

    addCoinArc(world, startX + g1 - 40, 410, 5, gap + 80, 60);
    addCoinRow(world, startX + g1 + gap + 100, 430, 4);

    addEnemy(world, 'crawler', startX + 180, 442, startX + 60, startX + 320, 1.4);
    addEnemy(world, 'bumble', startX + g1 + gap + 150, 260, startX + g1 + gap, startX + g1 + gap + 350, 1.6);
    if (Math.random() < 0.45) addPowerUp(world, 'shield', startX + 120, 420);

    world.nextGenX = startX + g1 + gap + g2;
  } else if (pattern === 1) {
    // High Sky Walkway with spring
    const len = 780;
    addGround(world, startX, len);
    addPlatform(world, startX + 140, 360, 110);
    addPlatform(world, startX + 300, 270, 130);
    addPlatform(world, startX + 480, 200, 120);

    world.springs.push({ x: startX + 240, y: 454, width: 34, height: 16, power: -15.0 });
    addCoinArc(world, startX + 240, 420, 6, 210, 90);
    addCoinRow(world, startX + 500, 150, 3);
    addPowerUp(world, 'speed', startX + 520, 150);

    addEnemy(world, 'sprout', startX + 350, 442, startX + 200, startX + 700, 1.5);
    world.nextGenX = startX + len;
  } else if (pattern === 2) {
    // Double gap with generous stepping stones
    const g1 = 320;
    const gap1 = 150;
    const island = 140;
    const gap2 = 160;
    const g2 = 360;

    addGround(world, startX, g1);
    addPlatform(world, startX + g1 + 20, 370, island - 40);
    addGround(world, startX + g1 + gap1 + island + gap2, g2);

    addPlatform(world, startX + g1 + gap1 + 40, 300, 90);

    addCoinArc(world, startX + g1 - 30, 420, 5, gap1 + 80, 50);
    addCoinArc(world, startX + g1 + gap1 + island - 30, 380, 5, gap2 + 80, 55);

    addEnemy(world, 'bumble', startX + g1 + gap1 + 60, 220, startX + g1, startX + g1 + gap1 + island + gap2, 1.6);
    if (Math.random() < 0.4) addPowerUp(world, 'magnet', startX + 100, 420);

    world.nextGenX = startX + g1 + gap1 + island + gap2 + g2;
  } else {
    // Crawler patrol terrace
    const len = 740;
    addGround(world, startX, len);
    addPlatform(world, startX + 150, 380, 140);
    addPlatform(world, startX + 350, 300, 140);
    addPlatform(world, startX + 550, 380, 120);

    addCoinRow(world, startX + 80, 430, 3);
    addCoinRow(world, startX + 370, 250, 3);
    addCoinRow(world, startX + 570, 330, 3);

    addEnemy(world, 'crawler', startX + 370, 272, startX + 350, startX + 470, 1.3);
    addEnemy(world, 'sprout', startX + 500, 442, startX + 350, startX + 700, 1.4);

    world.nextGenX = startX + len;
  }
}

// Tier 2: 1000 - 1500m
function generateTier2Chunk(world: WorldData, startX: number, pattern: number) {
  if (pattern === 0) {
    // Dual moving platforms over a deep gorge
    const g1 = 300;
    const gap = 340;
    const g2 = 380;
    addGround(world, startX, g1);
    addPlatform(world, startX + g1 + 30, 360, 85, 22, true, 55);
    addPlatform(world, startX + g1 + 180, 290, 85, 22, true, 50);
    addGround(world, startX + g1 + gap, g2);

    addCoinArc(world, startX + g1 - 30, 410, 5, 170, 55);
    addCoinArc(world, startX + g1 + 150, 340, 5, 170, 55);
    addCoinRow(world, startX + g1 + gap + 80, 430, 4);

    addEnemy(world, 'crawler', startX + 150, 442, startX + 40, startX + 260, 1.5);
    addEnemy(world, 'bumble', startX + g1 + gap + 140, 240, startX + g1 + gap, startX + g1 + gap + 340, 1.7);
    addPowerUp(world, 'jump', startX + 100, 420);

    world.nextGenX = startX + g1 + gap + g2;
  } else if (pattern === 1) {
    // Chonker intro on solid ridge
    const len = 780;
    addGround(world, startX, len);
    addPlatform(world, startX + 180, 360, 120);
    addPlatform(world, startX + 360, 270, 140);
    addPlatform(world, startX + 560, 360, 120);

    addCoinRow(world, startX + 80, 430, 3);
    addCoinRow(world, startX + 380, 220, 4);
    addCoinRow(world, startX + 580, 310, 3);

    addEnemy(world, 'chonker', startX + 400, 434, startX + 240, startX + 700, 1.1);
    addEnemy(world, 'sprout', startX + 180, 442, startX + 60, startX + 320, 1.4);
    if (Math.random() < 0.5) addPowerUp(world, 'shield', startX + 400, 220);

    world.nextGenX = startX + len;
  } else if (pattern === 2) {
    // Mega spring launch to high canopy
    const len = 820;
    addGround(world, startX, len);
    addPlatform(world, startX + 200, 350, 110);
    addPlatform(world, startX + 380, 240, 130);
    addPlatform(world, startX + 560, 160, 140);

    world.springs.push({ x: startX + 280, y: 454, width: 34, height: 16, power: -16.0 });
    addCoinArc(world, startX + 280, 420, 6, 260, 100);
    addCoinRow(world, startX + 580, 110, 4);
    addPowerUp(world, 'magnet', startX + 600, 110);

    addEnemy(world, 'crawler', startX + 400, 212, startX + 380, startX + 490, 1.4);
    addEnemy(world, 'bumble', startX + 650, 250, startX + 500, startX + 780, 1.8);

    world.nextGenX = startX + len;
  } else {
    // Hopper bounce sequence
    const len = 750;
    addGround(world, startX, len);
    addPlatform(world, startX + 160, 370, 120);
    addPlatform(world, startX + 340, 290, 130);
    addPlatform(world, startX + 520, 370, 120);

    addCoinRow(world, startX + 80, 430, 4);
    addCoinArc(world, startX + 320, 240, 5, 150, 45);

    addEnemy(world, 'hopper', startX + 360, 440, startX + 200, startX + 650, 1.3);
    addEnemy(world, 'sprout', startX + 180, 442, startX + 60, startX + 320, 1.5);

    world.nextGenX = startX + len;
  }
}

// Tier 3: 1500 - 2500m
function generateTier3Chunk(world: WorldData, startX: number, pattern: number) {
  if (pattern === 0) {
    // Multi-tiered Route: High speed route vs low solid route
    const len = 860;
    addGround(world, startX, len);
    addPlatform(world, startX + 120, 350, 130);
    addPlatform(world, startX + 290, 260, 140);
    addPlatform(world, startX + 480, 180, 140);
    addPlatform(world, startX + 660, 260, 120);

    // High route rewards
    addCoinRow(world, startX + 310, 210, 4);
    addCoinRow(world, startX + 500, 130, 4);
    addPowerUp(world, 'speed', startX + 520, 130);

    // Mysterious Star Runner Nova appearing on the high celestial platform!
    if (Math.random() < 0.6) {
      addNPC(world, 'nova', startX + 530, 142, "The stars illuminate your speed...", 'Nova');
    }

    // Ground hazards
    addEnemy(world, 'chonker', startX + 320, 434, startX + 150, startX + 550, 1.2);
    addEnemy(world, 'hopper', startX + 620, 440, startX + 450, startX + 800, 1.4);
    addEnemy(world, 'bumble', startX + 500, 260, startX + 350, startX + 650, 1.8);

    world.nextGenX = startX + len;
  } else if (pattern === 1) {
    // Three floating islands over open canyon
    const g1 = 280;
    const gap = 440;
    const g2 = 340;
    addGround(world, startX, g1);
    addPlatform(world, startX + g1 + 30, 360, 85);
    addPlatform(world, startX + g1 + 160, 280, 90, 22, true, 60);
    addPlatform(world, startX + g1 + 300, 350, 85);
    addGround(world, startX + g1 + gap, g2);

    addCoinArc(world, startX + g1 - 30, 410, 5, 160, 60);
    addCoinArc(world, startX + g1 + 140, 330, 5, 170, 60);
    addCoinArc(world, startX + g1 + 280, 390, 5, 160, 55);

    addEnemy(world, 'crawler', startX + 140, 442, startX + 40, startX + 240, 1.6);
    addEnemy(world, 'bumble', startX + g1 + 160, 200, startX + g1, startX + g1 + gap, 1.8);
    addPowerUp(world, 'jump', startX + 100, 420);

    world.nextGenX = startX + g1 + gap + g2;
  } else if (pattern === 2) {
    // Spring assault with dual crawlers
    const len = 800;
    addGround(world, startX, len);
    addPlatform(world, startX + 180, 360, 130);
    addPlatform(world, startX + 360, 280, 140);
    addPlatform(world, startX + 540, 200, 130);

    world.springs.push({ x: startX + 220, y: 454, width: 34, height: 16, power: -15.5 });
    addCoinArc(world, startX + 220, 420, 6, 220, 85);
    addCoinRow(world, startX + 560, 150, 3);
    addPowerUp(world, 'shield', startX + 580, 150);

    addEnemy(world, 'crawler', startX + 380, 252, startX + 360, startX + 480, 1.5);
    addEnemy(world, 'hopper', startX + 500, 440, startX + 300, startX + 750, 1.5);

    world.nextGenX = startX + len;
  } else {
    // Chonker & Hopper team
    const len = 780;
    addGround(world, startX, len);
    addPlatform(world, startX + 160, 370, 120);
    addPlatform(world, startX + 340, 290, 130);
    addPlatform(world, startX + 520, 370, 120);

    addCoinRow(world, startX + 80, 430, 4);
    addCoinArc(world, startX + 320, 240, 5, 150, 50);

    addEnemy(world, 'chonker', startX + 250, 434, startX + 100, startX + 450, 1.2);
    addEnemy(world, 'hopper', startX + 550, 440, startX + 400, startX + 720, 1.5);

    world.nextGenX = startX + len;
  }
}

// Tier 4: 2500m+ (Advanced master sections with starstriders)
function generateTier4Chunk(world: WorldData, startX: number, pattern: number) {
  if (pattern === 0) {
    // Floating Sky Islands with Starstrider
    const g1 = 260;
    const gap = 460;
    const g2 = 320;
    addGround(world, startX, g1);
    addPlatform(world, startX + g1 + 30, 350, 80, 22, true, 50);
    addPlatform(world, startX + g1 + 170, 260, 90, 22, true, 60);
    addPlatform(world, startX + g1 + 310, 330, 80, 22, true, 45);
    addGround(world, startX + g1 + gap, g2);

    addCoinArc(world, startX + g1 - 30, 410, 5, 170, 65);
    addCoinArc(world, startX + g1 + 150, 310, 5, 170, 65);
    addCoinRow(world, startX + g1 + gap + 80, 430, 4);

    addEnemy(world, 'starstrider', startX + 140, 428, startX + 40, startX + 240, 1.6);
    addEnemy(world, 'bumble', startX + g1 + 170, 180, startX + g1, startX + g1 + gap, 2.0);
    addPowerUp(world, 'speed', startX + 80, 420);

    world.nextGenX = startX + g1 + gap + g2;
  } else if (pattern === 1) {
    // High Altitude Gauntlet with Dual Springs
    const len = 860;
    addGround(world, startX, len);
    addPlatform(world, startX + 150, 360, 120);
    addPlatform(world, startX + 320, 270, 130);
    addPlatform(world, startX + 500, 180, 140);
    addPlatform(world, startX + 680, 260, 120);

    world.springs.push({ x: startX + 180, y: 454, width: 34, height: 16, power: -15.5 });
    world.springs.push({ x: startX + 540, y: 454, width: 34, height: 16, power: -15.5 });

    addCoinArc(world, startX + 180, 420, 6, 200, 85);
    addCoinRow(world, startX + 520, 130, 4);
    addCoinArc(world, startX + 540, 420, 6, 200, 85);
    addPowerUp(world, 'shield', startX + 540, 130);

    addEnemy(world, 'crawler', startX + 340, 242, startX + 320, startX + 430, 1.6);
    addEnemy(world, 'hopper', startX + 420, 440, startX + 250, startX + 680, 1.6);

    world.nextGenX = startX + len;
  } else if (pattern === 2) {
    // Double Chonker + Bumble Sky Hive
    const len = 820;
    addGround(world, startX, len);
    addPlatform(world, startX + 180, 370, 130);
    addPlatform(world, startX + 380, 290, 130);
    addPlatform(world, startX + 580, 370, 130);

    addCoinRow(world, startX + 60, 430, 4);
    addCoinArc(world, startX + 360, 240, 5, 160, 50);
    addCoinRow(world, startX + 680, 430, 4);

    addEnemy(world, 'chonker', startX + 260, 434, startX + 100, startX + 420, 1.2);
    addEnemy(world, 'chonker', startX + 620, 434, startX + 460, startX + 780, 1.2);
    addEnemy(world, 'bumble', startX + 400, 200, startX + 280, startX + 550, 1.9);
    addPowerUp(world, 'magnet', startX + 400, 240);

    world.nextGenX = startX + len;
  } else {
    // Fast sprint platform corridor with starstrider
    const len = 780;
    addGround(world, startX, len);
    addPlatform(world, startX + 160, 360, 110);
    addPlatform(world, startX + 320, 280, 130);
    addPlatform(world, startX + 500, 200, 120);

    addCoinRow(world, startX + 80, 430, 3);
    addCoinRow(world, startX + 340, 230, 4);
    addCoinRow(world, startX + 520, 150, 3);
    addPowerUp(world, 'jump', startX + 340, 230);

    addEnemy(world, 'starstrider', startX + 420, 428, startX + 250, startX + 650, 1.7);
    addEnemy(world, 'hopper', startX + 600, 440, startX + 450, startX + 740, 1.5);

    world.nextGenX = startX + len;
  }
}

// Cleanup of distant offscreen entities behind camera
export function cleanOldEntities(world: WorldData, minCamX: number) {
  const threshold = minCamX - 800;

  world.platforms = world.platforms.filter(p => p.x + p.width >= threshold);
  world.springs = world.springs.filter(s => s.x + s.width >= threshold);
  world.checkpoints = world.checkpoints.filter(cp => cp.x >= threshold);
  world.coins = world.coins.filter(c => c.x >= threshold);
  world.powerups = world.powerups.filter(p => p.x + p.width >= threshold);
  world.enemies = world.enemies.filter(e => e.x + e.width >= threshold);
  world.npcs = world.npcs.filter(n => n.x + n.width >= threshold);
  world.hills = world.hills.filter(h => h.x + (h.radius || 150) >= threshold);
  world.trees = world.trees.filter(t => t.x + 60 >= threshold);
  world.clouds = world.clouds.filter(c => c.x + (c.width || 100) >= threshold);
}
